package qsol.qsoljecheonweb.code.interfaceCode;

public interface CarCodegpCallInterpage {
    String getCodevalue(); // 코드
    String getCodelabel(); // 코드 이름
}
