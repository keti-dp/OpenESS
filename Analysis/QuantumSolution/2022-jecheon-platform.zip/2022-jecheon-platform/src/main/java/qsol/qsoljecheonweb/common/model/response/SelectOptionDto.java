package qsol.qsoljecheonweb.common.model.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SelectOptionDto {
	private String value;
	private String label;
}
