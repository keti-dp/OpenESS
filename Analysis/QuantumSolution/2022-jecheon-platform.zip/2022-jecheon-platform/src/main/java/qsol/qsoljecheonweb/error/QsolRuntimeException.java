package qsol.qsoljecheonweb.error;

public class QsolRuntimeException extends RuntimeException {
	public QsolRuntimeException() {
		super();
	}
	
	public QsolRuntimeException(String message) {
		super(message);
	}
}
