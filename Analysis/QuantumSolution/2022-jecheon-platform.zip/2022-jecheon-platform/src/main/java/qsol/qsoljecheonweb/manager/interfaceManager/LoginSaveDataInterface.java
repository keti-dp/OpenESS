package qsol.qsoljecheonweb.manager.interfaceManager;

public interface LoginSaveDataInterface {
    String getManagerId();
    String getManagerPw();
}
