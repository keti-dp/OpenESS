package qsol.qsoljecheonweb.diagnosis.interfaceDiagnosis;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public interface ReportDataInterface {


    BigDecimal getSoc();
    BigDecimal getSoh();
    String getGrade();

}
