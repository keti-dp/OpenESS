package qsol.qsoljecheonweb.code.interfaceCode;

public interface CarCodeInterface {
    // codeinfo
    String getCode();
    String getCodegp();
    String getCodenm();
    Boolean getUseyn();
    String getUseynMessage();
}
