package qsol.qsoljecheonweb.diagnosis.interfaceDiagnosis;

public interface TestMasterInterface {

    int getLocid();
    int getTestid();
}
