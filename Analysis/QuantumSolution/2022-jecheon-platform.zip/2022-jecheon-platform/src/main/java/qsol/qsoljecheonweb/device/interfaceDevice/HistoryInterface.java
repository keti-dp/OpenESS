package qsol.qsoljecheonweb.device.interfaceDevice;

import java.time.LocalDateTime;

public interface HistoryInterface {

    int getTestid();
    Long getLocid();
    String getCid();
}
