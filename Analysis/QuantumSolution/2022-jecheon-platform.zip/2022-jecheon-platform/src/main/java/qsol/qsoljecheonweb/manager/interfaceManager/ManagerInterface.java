package qsol.qsoljecheonweb.manager.interfaceManager;

public interface ManagerInterface {
    String getManagerId();
    String getManagerNm();
    String getManagerPhone();
    String getManagerTel();
    String getManagerEmail();
    String getUsingStatus();
}
