package com.qsol.jecheonessplatform.chargeData.entity;


import lombok.*;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;;


@Entity
@Table(name = "tb_test_data")
@Getter
@Setter
@ToString
public class TestData {

  @Id
  @Column(name = "TEST_DATA_ID")
  private Long testDataId;

  @Column(name = "TEST_ID")
  private Long testId;

  @Column(name = "REQ_ID")
  private Long reqId;

  @Column(name = "LOC_ID")
  private Long locId;

  @Column(name = "SOC")
  private BigDecimal soc;

  @Column(name = "REMAIN_FULL_SOC_TIME")
  private Long remainFullSocTime;

  @Column(name = "VOLTAGE")
  private Double voltage;

  @Column(name = "CURRENT")
  private Double current;

  @Column(name = "REGIST_DT")
  private Timestamp registDt;

  @Transient
  private Long timestampDiff;

}
