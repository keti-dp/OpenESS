package com.qsol.jecheonessplatform.sameVehicle.dto.reponse;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Transient;
import java.math.BigDecimal;
import java.sql.Timestamp;

@NoArgsConstructor
@Getter
@Setter
@Data
public class VehicleDataResponse {
    @Transient
    private String vehicleNo; // 차량번호
    @Transient
    private String varCd; // 차량제조사
    @Transient
    private String vmlCd; // 차량모델
    @Transient
    private String vmlView;
    @Transient
    private String carYear; // 차량연식
    @Transient
    private Integer batteryCap; // 배터리 용량
    @Transient
    private int count; // 충전 횟수 및 충전 차수
    @Transient
    private Timestamp maxRegistDt;
    @Transient
    private Timestamp minRegistDt;
    @Transient
    private String viewCheck;

    @Transient
    private BigDecimal startSoc;
    @Transient
    private BigDecimal lastSoc;
    @Transient
    private BigDecimal soh;

    @Transient
    private BigDecimal stdV;

    @Transient
    private Timestamp registDt;


}
