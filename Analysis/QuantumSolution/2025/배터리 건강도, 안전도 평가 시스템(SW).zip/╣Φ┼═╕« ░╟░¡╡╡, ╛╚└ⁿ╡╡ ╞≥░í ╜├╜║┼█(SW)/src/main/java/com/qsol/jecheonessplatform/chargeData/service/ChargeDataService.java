package com.qsol.jecheonessplatform.chargeData.service;

import com.qsol.jecheonessplatform.chargeData.dto.TestMasterSearchFormDto;
import com.qsol.jecheonessplatform.chargeData.entity.TestData;
import com.qsol.jecheonessplatform.chargeData.repository.TestDataRepository;
import com.qsol.jecheonessplatform.common.entity.TestMaster;
import com.qsol.jecheonessplatform.common.interfaceCommon.CommonInterface;
import com.qsol.jecheonessplatform.common.repository.TestMasterRepository;
import com.qsol.jecheonessplatform.common.service.CommonService;
import com.qsol.jecheonessplatform.common.util.QsolModelMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class ChargeDataService {
    private final TestMasterRepository testMasterRepository;
    private final TestDataRepository testDataRepository;
    private final CommonService commonService;

    public Page<TestMaster> getTestMasterList(Pageable pageable, TestMasterSearchFormDto testMasterSearchFormDto) {
        String vehicleNumber = testMasterSearchFormDto.getVehicleNumber();
        String sortData = testMasterSearchFormDto.getSortData() == null ? "registDt" : testMasterSearchFormDto.getSortData();
        String dataSortType = testMasterSearchFormDto.getDataSortType() == null ? "DESC" : testMasterSearchFormDto.getDataSortType();

        List<CommonInterface> getTestMasterList;
        if (dataSortType.equals("ASC")) {
            getTestMasterList = testMasterRepository.getTestMasterListAsc(vehicleNumber, sortData);
        } else {
            getTestMasterList = testMasterRepository.getTestMasterListDesc(vehicleNumber, sortData);
        }

        List<TestMaster> testMasterList = QsolModelMapper.map(getTestMasterList, TestMaster.class);

        return commonService.pagingList(testMasterList, pageable);
    }

    public TestMaster getTestMasterData(Integer testId) {
        CommonInterface testMaster = testMasterRepository.findTopByTestId(testId);
        return (testMaster == null) ? null : QsolModelMapper.map(testMaster, TestMaster.class);
    }

    public Page<TestData> getChargeCaseDataList(Pageable pageable, Long testId) {
        List<TestData> testDataList = testDataRepository.findByTestIdOrderByRegistDtAsc(testId);

        List<TestData> returnDataList = new ArrayList<>();
        BigDecimal compareSoc = null;

        for (TestData testData:testDataList) {
            BigDecimal soc = testData.getSoc();

            if (returnDataList.size() == 0) {
                compareSoc = soc;
                testData.setTimestampDiff(null);
                returnDataList.add(testData);
            } else {
                if (compareSoc.compareTo(soc) < 0) {
                    compareSoc = soc;

                    TestData lastTestData = returnDataList.get(returnDataList.size() - 1);
                    Long timestampDiff = (testData.getRegistDt().getTime() - lastTestData.getRegistDt().getTime()) / 1000;
                    testData.setTimestampDiff(timestampDiff);

                    returnDataList.add(testData);
                }
            }
        }

        return commonService.pagingList(returnDataList, pageable);
    }

    public Map<String, Object> getSohReport(Integer testId) {
        long startTime = System.currentTimeMillis(); // 시작 시각 기록

        Map<String, Object> result = new HashMap<>();
        String resultMsg = testMasterRepository.getTestSoh(testId);
        if (resultMsg != null && resultMsg.endsWith(",")) {
            resultMsg = resultMsg.substring(0, resultMsg.length() - 1);
        }

        if (resultMsg.equals("-9")) {
            resultMsg = "건강도 평가 제외 대상입니다.";
        }

        CommonInterface testMasterData = testMasterRepository.findTopByTestId(testId);
        TestMaster testMaster = (testMasterData == null) ? null : QsolModelMapper.map(testMasterData, TestMaster.class);

        long endTime = System.currentTimeMillis(); // 종료 시각 기록
        double elapsedSeconds = (endTime - startTime) / 1000.0; // 밀리초 → 초 단위 변환

        result.put("brand", testMasterData.getVarCd());
        result.put("model", testMasterData.getVmlCd());
        result.put("year", testMasterData.getCarYear());
        result.put("vehicleNumber", testMasterData.getVehicleNo());

        result.put("result", resultMsg);
        result.put("elapsedTime", elapsedSeconds);
        result.put("testMaster", testMaster);

        return result;
    }
}
