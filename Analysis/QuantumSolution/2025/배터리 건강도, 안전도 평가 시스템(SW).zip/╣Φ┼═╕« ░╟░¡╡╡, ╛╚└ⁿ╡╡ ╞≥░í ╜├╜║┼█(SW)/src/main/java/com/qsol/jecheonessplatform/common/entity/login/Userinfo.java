package com.qsol.jecheonessplatform.common.entity.login;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Getter
@Entity
@Table(name = "tb_userinfo")
public class Userinfo {

    @Column(name = "user_id")
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int userId; // Auto

    @Column(nullable = false)
    private String username; // 아이디

    @Column(nullable = false)
    private String password; // 패스워드

    @Column(nullable = false)
    private String telno; // 연락처

    @Column(nullable = false)
    private String email; // 메일

    @Column(name = "pmn_cd", nullable = false)
    private String pmnCd; // 권한코드

    @Column(nullable = false)
    private String useyn; // 사용여부

    @Builder
    public Userinfo(int userId, String username, String password, String telno, String email, String pmnCd, String useyn) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.telno = telno;
        this.email = email;
        this.pmnCd = pmnCd;
        this.useyn = useyn;
    }
}
