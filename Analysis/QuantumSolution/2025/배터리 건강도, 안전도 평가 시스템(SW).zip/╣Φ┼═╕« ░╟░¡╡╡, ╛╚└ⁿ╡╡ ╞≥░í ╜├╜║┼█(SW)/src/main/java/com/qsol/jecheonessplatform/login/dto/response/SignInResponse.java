package com.qsol.jecheonessplatform.login.dto.response;

import com.qsol.jecheonessplatform.common.entity.login.Userinfo;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class SignInResponse {

    private String logInUsername;
    private String message;

    public SignInResponse(Userinfo userinfo, String message) {
        this.logInUsername = userinfo.getUsername();
        this.message = message;
    }
}
