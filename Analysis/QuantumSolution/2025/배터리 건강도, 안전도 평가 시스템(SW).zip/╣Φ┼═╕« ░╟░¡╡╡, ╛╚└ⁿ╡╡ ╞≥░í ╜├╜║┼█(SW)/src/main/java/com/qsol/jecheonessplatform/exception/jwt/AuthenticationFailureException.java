package com.qsol.jecheonessplatform.exception.jwt;

import com.qsol.jecheonessplatform.exception.GlobalException;

public class AuthenticationFailureException  extends GlobalException {

    private static final String MESSAGE = "authentication failed.";

    public AuthenticationFailureException(Throwable cause) {
        super(MESSAGE, cause);
    }
    @Override
    public int getStatusCode() {
        return 401;
    }
}
