package com.qsol.jecheonessplatform.common.service;

import com.qsol.jecheonessplatform.common.entity.CustomerCar;
import com.qsol.jecheonessplatform.common.entity.code.CodeInfo;
import com.qsol.jecheonessplatform.common.repository.CustomerCarRepository;
import lombok.RequiredArgsConstructor;
import org.json.JSONObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class CommonService {
    private final CustomerCarRepository customerCarRepository;

    public Page pagingList(List dataList, Pageable pageable) {
        long total = dataList.size();
        int start = (int) pageable.getOffset();
        int end = (start + pageable.getPageSize()) > dataList.size() ? dataList.size() : (start + pageable.getPageSize());
        return new PageImpl<>(dataList.subList(start, end), pageable, total);
    }

    public JSONObject findByVmlCdAndEvccidIsNotNull(String vmlCode) {
        JSONObject result = new JSONObject();
        List<CustomerCar> vehicleNoList = customerCarRepository.findByVmlCdAndEvccidIsNotNull(vmlCode);

        if(vehicleNoList.size() == 0) {
            result.put("result", "none");
        } else {
            result.put("result", vehicleNoList);
        }

        return result;
    }
}
