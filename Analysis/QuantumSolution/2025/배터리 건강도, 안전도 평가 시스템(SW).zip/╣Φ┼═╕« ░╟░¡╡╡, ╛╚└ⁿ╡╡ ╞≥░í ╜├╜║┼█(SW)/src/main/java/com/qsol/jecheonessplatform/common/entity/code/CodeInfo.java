package com.qsol.jecheonessplatform.common.entity.code;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

@Entity
@Table(name="tb_codeinfo")
@Setter
@Getter
@ToString
@IdClass(CodeInfoId.class)   //코드테이블의 codegp, code가 primark key로 정의
public class CodeInfo {
    @Id
    @Column(name="code")
    private String code;

    @Id
    @Column(name="codegp")
    private String codeGp;

    @Column(name="codenm")
    private String codeNm;

    @Column(name="reference")
    private String reference;

    @Column(name="useyn")
    private Boolean useYn;
}
