package com.qsol.jecheonessplatform.common.entity;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;

@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Getter
@Entity
@Table(name = "tb_test_car")
public class TestCar {

    @Column(name = "test_car_id")
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int testCarId; // Auto

    @Column(name = "test_id")
    private int testId; // 테스트 Id

    @Column(name = "vehicle_no", nullable = false)
    private String vehicleNo; // 차량번호

    @Column(name = "var_cd", nullable = false)
    private String varCd; // 차량 제조사

    @Column(name = "vml_cd", nullable = false)
    private String vmlCd; // 차량 모델

    @Column(name = "car_year", nullable = false)
    private String carYear; // 차량 연식

    @Column(nullable = false)
    private int mileage; // 차량 주행거리

    @Column(name = "regist_dt", nullable = false)
    private Timestamp registDt; // 등록일자

}
