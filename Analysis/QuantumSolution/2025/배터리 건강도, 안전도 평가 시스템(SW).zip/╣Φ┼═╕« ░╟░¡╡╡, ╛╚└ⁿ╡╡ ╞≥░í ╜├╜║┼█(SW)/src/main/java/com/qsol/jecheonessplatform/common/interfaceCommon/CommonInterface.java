package com.qsol.jecheonessplatform.common.interfaceCommon;

import java.math.BigDecimal;
import java.sql.Timestamp;

public interface CommonInterface {

    String getVehicleNo(); // 차량번호
    String getVarCd(); // 차량 제조사
    String getVmlCd(); // 차량 모델

    Integer getReqId();

    String getVmlView();
    String getCarYear(); // 차량 연식
    Integer getBatteryCap(); // 배터리 용량
    BigDecimal getStartSoc(); // 시작 SoC
    BigDecimal getLastSoc(); // 종료 SoC
    BigDecimal getSoh(); // SoH
    Timestamp getRegistDt(); // 등록일자
    Integer getCount(); // 충전 횟수 및 충전 차수
    String getCustomerId(); // 고객식별Id

    BigDecimal getStdV();
    BigDecimal getStdV2();
    BigDecimal getStdVAvg();

//    --- charge count ---
    Timestamp getMaxRegistDt();
    Timestamp getMinRegistDt();

    /* charge data */
    Integer getTestId();
    Integer getLocId();
    String getEvccId();
    Timestamp getStartDt();
    Timestamp getEndDt();
    Integer getSuccessYn();
    String getResultMsg();
    String getManagerId();

}
