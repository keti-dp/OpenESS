package com.qsol.jecheonessplatform.chargeData.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter
@ToString
public class TestMasterSearchFormDto {

    private String vehicleNumber;

    private String sortData;

    private String dataSortType;


    private String searchQuery = "";

}
