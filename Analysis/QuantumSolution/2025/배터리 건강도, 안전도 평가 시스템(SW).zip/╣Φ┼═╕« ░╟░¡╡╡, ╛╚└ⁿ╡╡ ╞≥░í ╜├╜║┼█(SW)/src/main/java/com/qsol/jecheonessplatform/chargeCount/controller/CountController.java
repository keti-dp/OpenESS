package com.qsol.jecheonessplatform.chargeCount.controller;

import com.qsol.jecheonessplatform.chargeCount.service.CountService;
import com.qsol.jecheonessplatform.common.entity.CustomerCar;
import com.qsol.jecheonessplatform.common.entity.TestMaster;
import com.qsol.jecheonessplatform.common.repository.CustomerCarRepository;
import com.qsol.jecheonessplatform.common.service.CodeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.Optional;

@Slf4j
@RequiredArgsConstructor
@Controller
public class CountController {
    private final CustomerCarRepository customerCarRepository;
    private final CountService countService;
    private final CodeService codeService;

    @GetMapping("views/chargeCount/{page}")
    public String chargeCount(@PathVariable("page") Optional<Integer> page, Model model) {
        try {
            Pageable pageable = PageRequest.of(page.isPresent() ? page.get() : 0, 12);
            Page<TestMaster> testMasterPage = countService.chargeCount(pageable);

            model.addAttribute("chargeCountListData", testMasterPage);
            model.addAttribute("maxPage", 10);

        } catch (Exception e) {
            log.info("Error CountController chargeCount");
            e.printStackTrace();
        }
        return "views/chargeCount";
    }

    @ResponseBody
    @GetMapping("/getVarCodeNm")
    public String getVarCodeNm(@RequestParam("vmlCd") @Valid String vmlCd) {
        String varCdNm = codeService.getVarCodeNm(vmlCd);
        return varCdNm;
    }

    @ResponseBody
    @GetMapping("/redirect")
    public void redirectSameVehicle(HttpServletResponse response,
                                    @RequestParam("vmlCd") @Valid String vmlCd, @RequestParam("customerId") @Valid Integer customerId) {
        try {
            CustomerCar customerCar = customerCarRepository.findByCustomerId(customerId);
            String varCdNm = codeService.getVarCodeNm(vmlCd);

            JSONObject data = new JSONObject();
            data.put("varCd", varCdNm);
            data.put("customerCarId", customerCar.getId());

            response.setCharacterEncoding("UTF-8");
            response.setContentType("text/html; charset=UTF-8");
            response.getWriter().print(data);
        } catch (Exception e) {
            log.info("Error CountController redirectSameVehicle");
            e.printStackTrace();
        }
    }

    /*@ResponseBody
    @GetMapping("/getVarCodeNm/{vmlCd}")
    public String getVarCodeNm(@PathVariable @Valid String vmlCd) {
        String varCdNm = codeService.getVarCodeNm(vmlCd);
        return varCdNm;
    }*/

}


