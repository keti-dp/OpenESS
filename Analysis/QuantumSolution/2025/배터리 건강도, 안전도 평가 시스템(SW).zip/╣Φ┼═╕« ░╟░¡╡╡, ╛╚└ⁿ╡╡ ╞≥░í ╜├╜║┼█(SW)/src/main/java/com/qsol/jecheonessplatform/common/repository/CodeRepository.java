package com.qsol.jecheonessplatform.common.repository;

import com.qsol.jecheonessplatform.common.entity.code.CodeInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CodeRepository extends JpaRepository<CodeInfo, String> {
    List<CodeInfo> findByCodeGpAndUseYn(String codeGp, Boolean useYn);

    List<CodeInfo> findByCodeGpAndReferenceAndUseYn(String codeGp, String reference, boolean useYn);

    CodeInfo findByCodeAndUseYn(String code, boolean useYn);

    CodeInfo findByCodeNmAndUseYn(String reference, boolean b);
}
