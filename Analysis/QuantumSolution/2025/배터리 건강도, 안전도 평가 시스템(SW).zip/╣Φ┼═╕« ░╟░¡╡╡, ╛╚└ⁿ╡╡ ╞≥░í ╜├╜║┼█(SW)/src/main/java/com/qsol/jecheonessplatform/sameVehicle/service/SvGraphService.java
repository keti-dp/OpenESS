package com.qsol.jecheonessplatform.sameVehicle.service;

import Jama.Matrix;
import com.qsol.jecheonessplatform.common.entity.CustomerCar;
import com.qsol.jecheonessplatform.common.entity.TestMaster;
import com.qsol.jecheonessplatform.common.entity.code.CodeInfo;
import com.qsol.jecheonessplatform.common.interfaceCommon.CommonInterface;
import com.qsol.jecheonessplatform.common.repository.CodeRepository;
import com.qsol.jecheonessplatform.common.repository.CustomerCarRepository;
import com.qsol.jecheonessplatform.common.repository.TestMasterRepository;
import com.qsol.jecheonessplatform.common.util.QsolModelMapper;
import com.qsol.jecheonessplatform.sameVehicle.dto.request.VehicleDataRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.math3.stat.regression.SimpleRegression;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpSession;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Transactional(readOnly = true)
@RequiredArgsConstructor
@Service
public class SvGraphService {
    private final CustomerCarRepository customerCarRepository;
    private final TestMasterRepository testMasterRepository;
    private final CodeRepository codeRepository;

    private JSONObject healthChart(List<BigDecimal> sohChartPoint) {
        JSONObject result = new JSONObject();

        List<BigDecimal> interpolatedList = interpolateNullValues(sohChartPoint);
        JSONArray jsonArray = new JSONArray(interpolatedList);

        if(jsonArray.length() > 1) { // 사이즈 2 이상
            double[][] data = new double[jsonArray.length()][2];

            int nonLinearCount = 1;
            for (int i = 0; i < jsonArray.length(); i++) {
                if (!jsonArray.isNull(i)) {
                    data[i][0] = nonLinearCount;
                    data[i][1] = jsonArray.getDouble(i);
                    nonLinearCount++;
                }
            }

            // 비선형 회귀분석
            int degree = 3; // 다항식의 차수
            double[] params = nonlinearRegression(data, degree);
//                    System.out.println("Estimated parameters:");
//                    for (int i = 0; i < params.length; i++) {
//                        System.out.println("Param " + i + ": " + params[i]);
//                    }

            JSONArray nonLinearLine = new JSONArray();
            for(int i = 1; i < jsonArray.length()+1; i++) {
                double one = params[3] * Math.pow(i, 3);
                double two = params[2] * Math.pow(i, 2);
                double three = params[1] * i;
                double four = params[0];
                nonLinearLine.put(one + two + three + four);
            }

            result.put("nonLinearPoint", sohChartPoint);
            result.put("nonLinearLine", nonLinearLine);
        } else {
            result.put("nonLinearPoint", sohChartPoint);
            result.put("nonLinearLine", jsonArray);
        }

        return result;
    }

    private JSONObject btPredChart(List<Integer> indexList, List<TestMaster> sohDataList, List<BigDecimal> sohChartPoint, JSONArray sohChartLine ) {
        JSONObject result = new JSONObject();

        /* 추세선 : 선형회귀 */
        HashMap<String, Object> chartDataMap = getRegression(indexList, sohChartPoint);
        Double slope = (Double) chartDataMap.get("slope");
        sohChartLine = (JSONArray) chartDataMap.get("regressionData");

        /*List<Long> yBar = new ArrayList<>();
        for(int i = 0; i < sohChartPoint.size(); i++) {
            yBar.add(0L);
        }
        yBar.add(100L);
        result.put("yBar", yBar); // 마지막 충전값에 빨간색 세로줄 표시*/

        result.put("yBar", sohChartPoint.size() + 1);

        Double yMin = 9999D;
        for(int i = 0; i < sohDataList.size(); i++) {
            if(yMin > sohDataList.get(i).getSoh().doubleValue()) {
                yMin = sohDataList.get(i).getSoh().doubleValue();
            }
        }
        result.put("yMin", yMin); // yBar 표시할 때 yBar의 0값을 기준으로 그래프의 min 값이 잡히지 않도록 하기 위해

        result.put("sohChartLine", sohChartLine);
        result.put("sohChartPoint", sohChartPoint);

        result.put("slope", slope);

        return result;
    }

    private JSONObject stdChart(List<Integer> indexList, List<TestMaster> chargeDataList) {
        JSONObject result = new JSONObject();

        List<BigDecimal> stdDataList = new ArrayList<>();
        List<Integer> stdIndexList = new ArrayList<>();

        for (TestMaster testMaster : chargeDataList) {
            stdIndexList.add(chargeDataList.indexOf(testMaster) + 1);
            stdDataList.add(testMaster.getStdV2() != null ? testMaster.getStdV2().setScale(2, RoundingMode.HALF_UP) : testMaster.getStdV2());
        }

        result.put("stdIndexList", stdIndexList);
        result.put("stdData", stdDataList);
        return result;
    }

    private JSONObject chargePatternChart(List<Integer> indexList, List<TestMaster> chargeDataList) {
        JSONObject result = new JSONObject();
        HashMap<String, Object> chargePatternMap = new HashMap<>();

        BigDecimal socHighLimit = BigDecimal.valueOf(80);
        BigDecimal socLowLimit = BigDecimal.valueOf(20);

        Integer safeCharge = 0;
        Integer unsafeCharge = 0;
        BigDecimal unsafeChargeRate = BigDecimal.ZERO;

        for (TestMaster testMaster : chargeDataList) {
            if (testMaster.getStartSoc().compareTo(socLowLimit) <= 0 || testMaster.getLastSoc().compareTo(socHighLimit) > 0) {
                unsafeCharge += 1;
            } else {
                safeCharge += 1;
            }
        }

        unsafeChargeRate = BigDecimal.valueOf(unsafeCharge).divide(BigDecimal.valueOf(chargeDataList.size()), 3, RoundingMode.HALF_UP)
                .multiply(BigDecimal.valueOf(100))
                .setScale(1, RoundingMode.HALF_UP);

        chargePatternMap.put("safeCharge", safeCharge);
        chargePatternMap.put("unsafeCharge", unsafeCharge);
        chargePatternMap.put("unsafeChargeRate", unsafeChargeRate);

        result.put("chargePatternData", chargePatternMap);
        return result;
    }

    public JSONObject sameVehicleChart(VehicleDataRequest vehicleDataRequest, String name, HttpSession session) {
        JSONObject result = new JSONObject();

        try {
            CodeInfo codeInfo = codeRepository.findByCodeAndUseYn(vehicleDataRequest.getVmlCd(), true);

            Integer customerCarId = Integer.valueOf(vehicleDataRequest.getVehicleNo());
            CustomerCar customerCar = customerCarRepository.findById(customerCarId);
            String vehicleNumber = customerCar.getVehicleNo();

            List<TestMaster> sohDataList = getSohDataList(customerCar);

            if (sohDataList.size() > 0) {
                List<Integer> indexList = new ArrayList<>();

                LocalDateTime startDt = sohDataList.get(0).getRegistDt().toLocalDateTime();
                LocalDateTime endDt = sohDataList.get(sohDataList.size()-1).getRegistDt().toLocalDateTime();

                // 두 날짜 사이의 Duration 계산 => Duration을 일(day)로 변환
                long diffDays;
                diffDays = Duration.between(startDt, endDt).toDays();

                List<BigDecimal> sohChartPoint;
                for (int i = 0; i < diffDays+1; i++) {
                    indexList.add(i);
                }
                sohChartPoint = new ArrayList<>(Collections.nCopies((int) diffDays+1, null));

                BigDecimal maxValue = null;
                for (int i = 0; i < sohDataList.size(); i++) {
                    /* Y축 최대값 */
                    BigDecimal sohValue = sohDataList.get(i).getSoh();
                    if (maxValue == null || sohValue.compareTo(maxValue) > 0) {
                        maxValue = sohValue;
                    }
                    // 최대값이 95보다 크면 100으로, 그렇지 않으면 5 증가
                    maxValue = (maxValue.compareTo(BigDecimal.valueOf(95)) > 0) ? BigDecimal.valueOf(100) : maxValue.add(BigDecimal.valueOf(5));

                    /* chart data 전처리 */
                    long dataDiffDays = Duration.between(startDt, sohDataList.get(i).getRegistDt().toLocalDateTime()).toDays();
                    sohChartPoint.set((int) dataDiffDays, sohValue);
                }

                JSONArray sohChartLine = new JSONArray();
                if(name.equals("health")) { // 비선형
                    result = healthChart(sohChartPoint);
                } else if (name.equals("btPred")) {
                    result = btPredChart(indexList, sohDataList, sohChartPoint, sohChartLine);
                } else if (name.equals("std")) {
                    result = stdChart(indexList, sohDataList);

                    double avg = sohDataList.stream()
                            .filter(t -> t.getStdV2() != null)
                            .map(TestMaster::getStdV2)
                            .mapToDouble(BigDecimal::doubleValue)
                            .average()
                            .orElse(0.0);

                    BigDecimal totalStdAvg = BigDecimal.valueOf(avg);

                    // sohDataList.size() 만큼 평균값 채운 리스트 생성
//                    List<BigDecimal> totalStdAvgList = Collections.nCopies(sohDataList.size(), totalStdAvg);
//                    result.put("totalStdAvg", totalStdAvgList);
                    result.put("totalStdAvg", totalStdAvg);

                } else {
                    result = chargePatternChart(indexList, sohDataList);
                }


//                System.out.println(result);

                List<BigDecimal> stdList = sohDataList.stream()
                        .map(TestMaster::getStdV)
                        .filter(Objects::nonNull)
                        .collect(Collectors.toList());

                BigDecimal sum = stdList.stream()
                        .reduce(BigDecimal.ZERO, BigDecimal::add);

                BigDecimal avgStd = stdList.isEmpty()
                        ? BigDecimal.ZERO
                        : sum.divide(BigDecimal.valueOf(stdList.size()), 3, RoundingMode.HALF_UP);  // 소수점 10자리까지, 반올림

                result.put("std", avgStd);

                result.put("carModel", codeInfo.getCodeNm());
                result.put("vehicleNumber", vehicleNumber);
                result.put("indexList", indexList);
                result.put("maxValue", maxValue);
                result.put("listSize", sohDataList.size());

                result.put("firstCharge", startDt);
                result.put("lastCharge", endDt);
                result.put("chargeCount", sohDataList.size());
            } else {
                result.put("listSize", 0);
            }

            result.put("fmPredData", new ArrayList<>());
        } catch (Exception e) {
            log.info("Error SvGraphService sameVehicleChart");
            e.printStackTrace();
        }

        return result;
    }

    public List<TestMaster> getSohDataList(CustomerCar customerCar) {
        List<TestMaster> result = new ArrayList<>();
        try {
            List<CommonInterface> commonInterface = (customerCar != null) ? testMasterRepository.getSvChart(customerCar.getEvccid()) : null;
            result = QsolModelMapper.map(commonInterface, TestMaster.class);
        } catch (Exception e) {
            log.info("Error SvGraphService getSohDataList");
            e.printStackTrace();
        }
        return result;
    }

    public HashMap<String, Object>  getRegression(List<Integer> indexList, List<BigDecimal> sohDataList) {
//    public JSONArray getRegression(List<Integer> indexList, List<BigDecimal> sohDataList) {
        HashMap<String, Object> returnMap = new HashMap<>();

        JSONArray regressionData = new JSONArray();

        try {
//            Null Data 처리
            List<BigDecimal> interpolatedList = interpolateNullValues(sohDataList);

            JSONArray jsonArray = new JSONArray(interpolatedList);
            SimpleRegression regression = new SimpleRegression();

            int index = 0;
            boolean regressionListNullFlag = true;

            for (int i = 0; i < indexList.size(); i++) {
                if (!jsonArray.isNull(i)) {
                    regression.addData(index, jsonArray.getDouble(i));
                    regressionListNullFlag = false;
                }
                index++;
            }

            if (!regressionListNullFlag) {
                double slope = regression.getSlope();
                double intercept = regression.getIntercept();

                for (int i = 0; i < index; i++) {
                    double x = i;
                    double y = (slope * x + intercept) > 100 ? 100 : (slope * x + intercept);
                    JSONArray regressionJsonArray = new JSONArray();
                    int regressionIndex = (int) x;
                    int independentVariable = indexList.get(regressionIndex);
                    regressionJsonArray.put(independentVariable);
                    if(Double.isNaN(y)) {
                        y = 0D;
                    }
                    regressionJsonArray.put(y);
                    regressionData.put(regressionJsonArray);
                }

                returnMap.put("slope", slope);
                returnMap.put("regressionData", regressionData);
            }
        } catch (Exception e) {
            log.info("Error SvGraphService getRegression");
            e.printStackTrace();
        }

        return returnMap;
    }

    public static List<BigDecimal> interpolateNullValues(List<BigDecimal> data) {
        List<BigDecimal> interpolatedData = new ArrayList<>();

        try {
            int notNullDataCount = (int) data.stream().filter(value -> value != null).count();

//        Case1 : 전체 Data가 Null / Case2 : 전체 데이터 중 1개만 Not Null / Case3 : 전체 데이터 중 2개 이상 Not Null
            if (notNullDataCount == 0) {
                return interpolatedData;
            } else if (notNullDataCount == 1) {
//            전체 데이터 중 1개 데이터만 있을 경우 보간이 불가능하므로 1개 데이터로 추세선을 그려야함

                BigDecimal firstNonNullValue = data.stream()
                        .filter(Objects::nonNull) // null이 아닌 값 필터링
                        .findFirst() // 첫 번째로 나오는 값 가져오기
                        .orElse(null); // 만약 null이면 null 반환

                interpolatedData = data.stream()
                        .map(value -> value != null ? value : firstNonNullValue) // null인 경우 firstNonNullValue로 대체
                        .collect(Collectors.toList()); // 리스트로 변환

                return interpolatedData;
            } else {
                int i = 0;
                while (i < data.size()) {
                    // null 값인 경우 연속된 null 값의 시작 인덱스 찾기
                    if (data.get(i) == null) {
                        int startIndex = i;
                        // 연속된 null 값의 끝 인덱스 찾기
                        while (i < data.size() && data.get(i) == null) {
                            i++;
                        }
                        int endIndex = i - 1;

                        // 시작 인덱스의 이전 유효한 값 찾기
                        BigDecimal startValue = findPreviousValidValue(data, startIndex);

                        // 끝 인덱스의 다음 유효한 값 찾기
                        BigDecimal endValue = findNextValidValue(data, endIndex);

                        // 선형 보간 수행
                        if (startValue != null && endValue != null) {
                            int numValues = endIndex - startIndex + 1;
                            List<BigDecimal> interpolatedValues = linearInterpolate(startValue, endValue, numValues);
                            interpolatedData.addAll(interpolatedValues);
                        } else {
                            // 유효한 값이 없는 경우 그대로 추가
                            for (int j = startIndex; j <= endIndex; j++) {
                                interpolatedData.add(null);
                            }
                        }
                    } else {
                        // 유효한 값인 경우 그대로 추가
                        interpolatedData.add(data.get(i));
                        i++;
                    }
                }
            }

        } catch (Exception e) {
            log.info("Error SvGraphService interpolateNullValues");
            e.printStackTrace();
        }

        return interpolatedData;
    }

    // 이전 유효한 값 찾기
    private static BigDecimal findPreviousValidValue(List<BigDecimal> data, int index) {
        for (int i = index - 1; i >= 0; i--) {
            BigDecimal value = data.get(i);
            if (value != null) {
                return value;
            }
        }
        return null;
    }

    // 다음 유효한 값 찾기
    private static BigDecimal findNextValidValue(List<BigDecimal> data, int index) {
        for (int i = index + 1; i < data.size(); i++) {
            BigDecimal value = data.get(i);
            if (value != null) {
                return value;
            }
        }
        return null;
    }

// 선형 보간 수행
    private static List<BigDecimal> linearInterpolate(BigDecimal start, BigDecimal end, int numValues) {
        List<BigDecimal> interpolatedValues = new ArrayList<>();
        try {
            BigDecimal step = end.subtract(start).divide(BigDecimal.valueOf(numValues), 2, BigDecimal.ROUND_CEILING);

            for (int i = 0; i < numValues; i++) {
                BigDecimal interpolatedValue = start.add(step.multiply(BigDecimal.valueOf(i + 1)));
                interpolatedValues.add(interpolatedValue);
            }
        } catch (Exception e) {
            log.info("Error SvGraphService linearInterpolate");
            e.printStackTrace();
        }

        return interpolatedValues;
    }


    // 비선형 회귀분석
    public static double[] nonlinearRegression(double[][] data, int degree) {
        // 데이터 포인트 개수
        int n = data.length;

        // 설명 변수 (x)와 반응 변수 (y)를 담을 행렬 초기화
        double[][] X = new double[n][degree + 1];
        double[] y = new double[n];

        // 데이터 배열을 행렬 형태로 변환
        for (int i = 0; i < n; i++) {
            double xValue = data[i][0];
            for (int j = 0; j <= degree; j++) {
                X[i][j] = Math.pow(xValue, j);
            }
            y[i] = data[i][1];
        }

        // 행렬로 변환
        Matrix XMatrix = new Matrix(X);
        Matrix yMatrix = new Matrix(y, n);

        // 최소 제곱법으로 회귀 계수 계산
        Matrix theta = XMatrix.transpose().times(XMatrix).inverse().times(XMatrix.transpose()).times(yMatrix);

        // 회귀 계수 반환
        return theta.getColumnPackedCopy();
    }
}

