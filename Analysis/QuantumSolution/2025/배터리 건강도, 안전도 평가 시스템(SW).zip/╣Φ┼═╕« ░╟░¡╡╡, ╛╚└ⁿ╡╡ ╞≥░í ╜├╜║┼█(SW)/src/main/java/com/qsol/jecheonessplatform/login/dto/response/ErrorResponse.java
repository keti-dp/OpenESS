package com.qsol.jecheonessplatform.login.dto.response;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@NoArgsConstructor
@Data
public class ErrorResponse {
    private int statusCode;
    private String message;

    private Map<String, String> reason;

    @Builder
    public ErrorResponse(int statusCode, String message, Map<String, String> reason) {
        this.statusCode = statusCode;
        this.message = message;
        this.reason = reason;
    }
}
