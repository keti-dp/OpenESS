package com.qsol.jecheonessplatform.sameTypeVehicle.service;

import com.qsol.jecheonessplatform.common.entity.CustomerCar;
import com.qsol.jecheonessplatform.common.entity.TestMaster;
import com.qsol.jecheonessplatform.common.interfaceCommon.CommonInterface;
import com.qsol.jecheonessplatform.common.repository.CodeRepository;
import com.qsol.jecheonessplatform.common.repository.CustomerCarRepository;
import com.qsol.jecheonessplatform.common.repository.TestMasterRepository;
import com.qsol.jecheonessplatform.common.util.QsolModelMapper;
import com.qsol.jecheonessplatform.sameTypeVehicle.dto.SameTypeVehicleSearchFormDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.math3.stat.regression.SimpleRegression;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
@Slf4j
public class SameTypeVehicleService {
    private final CustomerCarRepository customerCarRepository;
    private final TestMasterRepository testMasterRepository;
    private final CodeRepository codeRepository;


    public TestMaster getTestMasterData(String customerId) {
        CommonInterface commonInterface = testMasterRepository.findTopByCustomerIdOrderByRegistDtDesc(customerId);
        return (commonInterface == null) ? null : QsolModelMapper.map(commonInterface, TestMaster.class);
    }

    public CustomerCar getCustomerCar(Integer customerId) {
        return customerCarRepository.findByCustomerId(customerId);
    }

    public List<TestMaster> getTestMasterDataList(String vmlCd, String carYear, String customerId, Timestamp registDt) {
        List<CommonInterface> commonInterfaceList = testMasterRepository.findByVmlCdAndCarYearAndNotCustomerIdAndRegistDtAfterOrderByRegistDtDesc(vmlCd, carYear, customerId, registDt);
        return (commonInterfaceList.size() == 0) ? null : QsolModelMapper.map(commonInterfaceList, TestMaster.class);
    }

    public List<CustomerCar> getCarYearList(String vmlCd) {
        return customerCarRepository.findByVmlCd(vmlCd);
    }

    public List<CustomerCar> getVehicleNumberList(String vmlCd, String carYear) {
        return customerCarRepository.findByVmlCdAndCarYear(vmlCd, carYear);
    }


    public JSONObject getResponseSohData(SameTypeVehicleSearchFormDto sameTypeVehicleSearchFormDto) {
        JSONObject result = new JSONObject();

        try {
            String customerId = sameTypeVehicleSearchFormDto.getCustomerId();
            CustomerCar customerCar = customerCarRepository.findByCustomerId(Integer.valueOf(customerId));
            String vehicleNumber = customerCar.getVehicleNo();
            String vmlCdName = codeRepository.findByCodeAndUseYn(sameTypeVehicleSearchFormDto.getVmlCd(), true).getCodeNm();

            List<TestMaster> sohDataList = getSohDataList(sameTypeVehicleSearchFormDto);

            if (sohDataList.size() > 0) {
                List<Integer> indexList = new ArrayList<>();

                LocalDateTime startDt = sohDataList.get(0).getRegistDt().toLocalDateTime();
                LocalDateTime now = new Timestamp(System.currentTimeMillis()).toLocalDateTime();

                // 두 날짜 사이의 Duration 계산 => Duration을 일(day)로 변환
                long diffDays = Duration.between(startDt, now).toDays();

                for (int i = 0; i < diffDays; i++) {
                    indexList.add(i);
                }

                List<BigDecimal> searchCarList = new ArrayList<>(Collections.nCopies((int) diffDays, null));
                List<BigDecimal> notSearchCarList = new ArrayList<>(Collections.nCopies((int) diffDays, null));

                BigDecimal maxValue = null;
                for (int i = 0; i < sohDataList.size(); i++) {
                    /* Y축 최대값 */
                    BigDecimal sohValue = sohDataList.get(i).getSoh();
                    if (maxValue == null || sohValue.compareTo(maxValue) > 0) {
                        maxValue = sohValue;
                    }
                    // 최대값이 95보다 크면 100으로, 그렇지 않으면 5 증가
                    maxValue = (maxValue.compareTo(BigDecimal.valueOf(95)) > 0) ? BigDecimal.valueOf(100) : maxValue.add(BigDecimal.valueOf(5));

                    /* chart data 전처리 */
                    long dataDiffDays = Duration.between(startDt, sohDataList.get(i).getRegistDt().toLocalDateTime()).toDays();
                    boolean isCustomerMatch = sohDataList.get(i).getCustomerId().equals(customerId);

                    if (isCustomerMatch) {
                        searchCarList.set((int) dataDiffDays, sohValue);
                    } else {
                        notSearchCarList.set((int) dataDiffDays, sohValue);
                    }
                }

                /* 추세선 : 선형회귀 */
                JSONArray searchCarRegressionJsonArray = getRegression(indexList, searchCarList).getJSONArray("sohRegressionList");
                Double searchCarSlope = getRegression(indexList, searchCarList).getDouble("slope");

                JSONArray notSearchCarRegressionJsonArray = getRegression(indexList, notSearchCarList).getJSONArray("sohRegressionList");
                Double notSearchCarSlope = null;
                if (getRegression(indexList, notSearchCarList).has("slope")) {
                    notSearchCarSlope = getRegression(indexList, notSearchCarList).getDouble("slope");
                }

                String sohPercentageDiff = null;

                if (notSearchCarSlope != null) {
                    sohPercentageDiff = String.format("%.0f", ((searchCarSlope - notSearchCarSlope) / Math.abs(notSearchCarSlope)) * 100);
                }

                result.put("vmlCd", vmlCdName);
                result.put("vehicleNumber", vehicleNumber);
                result.put("indexList", indexList);
                result.put("searchCarList", searchCarList);
                result.put("notSearchCarList", notSearchCarList);
                result.put("searchCarRegressionJsonArray", searchCarRegressionJsonArray);
                result.put("notSearchCarRegressionJsonArray", notSearchCarRegressionJsonArray);
                result.put("maxValue", maxValue);
                result.put("sohPercentageDiff", sohPercentageDiff);
                result.put("listSize", sohDataList.size());
            } else {
                result.put("listSize", 0);
            }
        } catch (Exception e) {
            log.info("Error SameTypeVehicleService getResponseSohData : " + sameTypeVehicleSearchFormDto);
            e.printStackTrace();
        }

        return result;
    }

    public List<TestMaster> getSohDataList(SameTypeVehicleSearchFormDto sameTypeVehicleSearchFormDto) {
        List<TestMaster> returnList = new ArrayList<>();
        try {
            String vmlCd = sameTypeVehicleSearchFormDto.getVmlCd();
            String carYear = sameTypeVehicleSearchFormDto.getCarYear();
            String customerId = sameTypeVehicleSearchFormDto.getCustomerId();

            CommonInterface testMaster = testMasterRepository.findTopByCustomerIdOrderByRegistDtAsc(customerId);

            if (testMaster != null) {
                TestMaster testMasterMapped = QsolModelMapper.map(testMaster, TestMaster.class);

                List<CommonInterface> commonInterface = testMasterRepository.findByVmlCdAndCarYearOrderByRegistDtAsc(vmlCd, carYear, testMasterMapped.getRegistDt());
                returnList = (commonInterface == null) ? null : QsolModelMapper.map(commonInterface, TestMaster.class);
            }
        } catch (Exception e) {
            log.info("Error SameTypeVehicleService getSohDataList : " + sameTypeVehicleSearchFormDto);
            e.printStackTrace();
        }
        return returnList;
    }

    public JSONObject getRegression(List<Integer> indexList, List<BigDecimal> sohDataList) {
        JSONObject regressionData = new JSONObject();

        try {
//            Null Data 처리
            List<BigDecimal> interpolatedList = interpolateNullValues(sohDataList);

            JSONArray jsonArray = new JSONArray(interpolatedList);
            SimpleRegression regression = new SimpleRegression();

            int index = 0;
            boolean regressionListNullFlag = true;

            for (int i = 0; i < indexList.size(); i++) {
                if (!jsonArray.isNull(i)) {
                    regression.addData(index, jsonArray.getDouble(i));
                    regressionListNullFlag = false;
                }
                index++;
            }

            JSONArray sohRegressionList = new JSONArray();

            if (!regressionListNullFlag) {
                double slope = regression.getSlope();
                double intercept = regression.getIntercept();

                for (int i = 0; i < index; i++) {
                    double x = i;
                    double y = (slope * x + intercept) > 100 ? 100 : (slope * x + intercept);
                    JSONArray regressionJsonArray = new JSONArray();
                    int regressionIndex = (int) x;
                    int independentVariable = indexList.get(regressionIndex);
                    regressionJsonArray.put(independentVariable);
                    regressionJsonArray.put(y);
                    sohRegressionList.put(regressionJsonArray);
                    regressionData.put("slope", slope);
                }
            }

            regressionData.put("sohRegressionList", sohRegressionList);
        } catch (Exception e) {
            log.info("Error SameTypeVehicleService getRegression");
            e.printStackTrace();
        }

        return regressionData;
    }

    /* Null Data 전처리 */
    public static List<BigDecimal> interpolateNullValues(List<BigDecimal> data) {
        List<BigDecimal> interpolatedData = new ArrayList<>();

        try {
            int notNullDataCount = (int) data.stream().filter(value -> value != null).count();

//        Case1 : 전체 Data가 Null / Case2 : 전체 데이터 중 1개만 Not Null / Case3 : 전체 데이터 중 2개 이상 Not Null
            if (notNullDataCount == 0) {
                return interpolatedData;
            } else if (notNullDataCount == 1) {
//            전체 데이터 중 1개 데이터만 있을 경우 보간이 불가능하므로 1개 데이터로 추세선을 그려야함

                BigDecimal firstNonNullValue = data.stream()
                        .filter(Objects::nonNull) // null이 아닌 값 필터링
                        .findFirst() // 첫 번째로 나오는 값 가져오기
                        .orElse(null); // 만약 null이면 null 반환

                interpolatedData = data.stream()
                        .map(value -> value != null ? value : firstNonNullValue) // null인 경우 firstNonNullValue로 대체
                        .collect(Collectors.toList()); // 리스트로 변환

                return interpolatedData;
            } else {
                int i = 0;
                while (i < data.size()) {
                    // null 값인 경우 연속된 null 값의 시작 인덱스 찾기
                    if (data.get(i) == null) {
                        int startIndex = i;
                        // 연속된 null 값의 끝 인덱스 찾기
                        while (i < data.size() && data.get(i) == null) {
                            i++;
                        }
                        int endIndex = i - 1;

                        // 시작 인덱스의 이전 유효한 값 찾기
                        BigDecimal startValue = findPreviousValidValue(data, startIndex);

                        // 끝 인덱스의 다음 유효한 값 찾기
                        BigDecimal endValue = findNextValidValue(data, endIndex);

                        // 선형 보간 수행
                        if (startValue != null && endValue != null) {
                            int numValues = endIndex - startIndex + 1;
                            List<BigDecimal> interpolatedValues = linearInterpolate(startValue, endValue, numValues);
                            interpolatedData.addAll(interpolatedValues);
                        } else {
                            // 유효한 값이 없는 경우 그대로 추가
                            for (int j = startIndex; j <= endIndex; j++) {
                                interpolatedData.add(null);
                            }
                        }
                    } else {
                        // 유효한 값인 경우 그대로 추가
                        interpolatedData.add(data.get(i));
                        i++;
                    }
                }
            }

        } catch (Exception e) {
            log.info("Error SameTypeVehicleService interpolateNullValues");
            e.printStackTrace();
        }

        return interpolatedData;
    }

    // 이전 유효한 값 찾기
    private static BigDecimal findPreviousValidValue(List<BigDecimal> data, int index) {
        for (int i = index - 1; i >= 0; i--) {
            BigDecimal value = data.get(i);
            if (value != null) {
                return value;
            }
        }
        return null;
    }

    // 다음 유효한 값 찾기
    private static BigDecimal findNextValidValue(List<BigDecimal> data, int index) {
        for (int i = index + 1; i < data.size(); i++) {
            BigDecimal value = data.get(i);
            if (value != null) {
                return value;
            }
        }
        return null;
    }

    // 선형 보간 수행
    private static List<BigDecimal> linearInterpolate(BigDecimal start, BigDecimal end, int numValues) {
        List<BigDecimal> interpolatedValues = new ArrayList<>();
        try {
            BigDecimal step = end.subtract(start).divide(BigDecimal.valueOf(numValues), 2, BigDecimal.ROUND_CEILING);

            for (int i = 0; i < numValues; i++) {
                BigDecimal interpolatedValue = start.add(step.multiply(BigDecimal.valueOf(i + 1)));
                interpolatedValues.add(interpolatedValue);
            }
        } catch (Exception e) {
            log.info("Error SameTypeVehicleService linearInterpolate");
            e.printStackTrace();
        }

        return interpolatedValues;
    }
}
