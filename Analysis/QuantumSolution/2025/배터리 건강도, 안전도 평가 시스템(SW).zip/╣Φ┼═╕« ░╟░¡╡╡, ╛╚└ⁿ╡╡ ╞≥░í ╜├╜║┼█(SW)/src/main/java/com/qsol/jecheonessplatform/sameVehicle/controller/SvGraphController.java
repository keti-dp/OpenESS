package com.qsol.jecheonessplatform.sameVehicle.controller;

import com.qsol.jecheonessplatform.common.entity.code.CodeInfo;
import com.qsol.jecheonessplatform.common.service.CodeService;
import com.qsol.jecheonessplatform.sameVehicle.dto.reponse.SelectBoxResponse;
import com.qsol.jecheonessplatform.sameVehicle.dto.request.VehicleDataRequest;
import com.qsol.jecheonessplatform.sameVehicle.service.SvGraphService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Slf4j
@RequiredArgsConstructor
@Controller
public class SvGraphController {
    private final CodeService codeService;
    private final SvGraphService svGraphService;

    @GetMapping("/views/sameVehicleGraphReadyCode/{vmlCd}/{vehicleNo}")
    public String sameVehicleGraphMove(@PathVariable("vmlCd") String vmlCd, @PathVariable("vehicleNo") String vehicleNo, Model model) {
        try {
            codeService.findByCodeGpAndUseYn("VAR", true, model);

            SelectBoxResponse sbr = new SelectBoxResponse();
            CodeInfo ci = codeService.findByCodeAndUseYn(vmlCd, true);
            sbr.setVarSelect(ci.getReference());
            sbr.setVmlSelect(ci.getCode());
            sbr.setVehicleNo(vehicleNo);

            model.addAttribute("selectBoxResponse", sbr);
        } catch (Exception e) {
            log.info("Error SvGraphController sameVehicleGraphMove");
            e.printStackTrace();
        }
        return "views/sameVehicleGraph";
    }

    @ResponseBody
    @PostMapping(value = "/views/getSvChart/{name}")
    public void getSvChart(
            @PathVariable("name") String name, HttpServletResponse response,
            VehicleDataRequest vehicleDataRequest,
            HttpSession session) {
        try {
            JSONObject data = svGraphService.sameVehicleChart(vehicleDataRequest, name, session);
            response.setCharacterEncoding("UTF-8");
            response.setContentType("text/html; charset=UTF-8");
            response.getWriter().print(data);
        } catch (Exception e) {
            log.info("Error SameTypeVehicleController responseChartData");
            e.printStackTrace();
        }
    }
}