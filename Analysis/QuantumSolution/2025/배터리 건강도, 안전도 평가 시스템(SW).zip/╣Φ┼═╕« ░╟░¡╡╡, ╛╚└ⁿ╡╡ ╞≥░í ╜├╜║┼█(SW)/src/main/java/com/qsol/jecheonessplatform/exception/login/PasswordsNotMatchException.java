package com.qsol.jecheonessplatform.exception.login;

import com.qsol.jecheonessplatform.exception.GlobalException;

public class PasswordsNotMatchException extends GlobalException {

    private static final String MESSAGE = "Passwords do not match.";

    public PasswordsNotMatchException() {
        super(MESSAGE);
    }

    @Override
    public int getStatusCode() {
        return 400;
    }
}
