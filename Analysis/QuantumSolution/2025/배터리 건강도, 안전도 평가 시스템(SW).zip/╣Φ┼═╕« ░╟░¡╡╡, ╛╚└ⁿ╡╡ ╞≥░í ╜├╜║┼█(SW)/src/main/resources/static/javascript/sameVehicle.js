let varCd = "none";
let vmlCd = "none";
let vehicleNo = "none";

$(document).ready(function () {
    $(".gnb .same_vehicle").parent().addClass("active");
    $(".sv_etc_button").attr("disabled", true).addClass("disabled_button");

    // ┌─────────────────────────── 충전 횟수 페이지에서 온 경우 데이터를 저장
    let query = window.location.search;
    let param = new URLSearchParams(query);

    let vmlCd = param.get("vmlCd");
    let varCd = param.get("varCdNm");
    let customerCarId = param.get("customerCarId");

    if (param.size === 0) { // 파라미터가 없을 때 (left_menu에서 접근)
        $("#listViewOn").show();
        $("#graphViewOn").hide();
        $("#contentChange").text("그래프로 보기");
        $("#contentChange").val("list");

        setTimeout(function () {
            $(".search_wrap select[name='varCode'] option:first").prop("selected", true);
            $(".search_wrap select[name='vmlCode'] option:first").prop("selected", true);
            $(".search_wrap select[name='vehicleName'] option:first").prop("selected", true);
        },0);
    } else {
        $("#listViewOn").show();
        $("#graphViewOn").hide();
        $("#contentChange").text("그래프로 보기");
        $("#contentChange").val("list");

        $(".search_wrap select[name='varCode']").val(varCd).attr("selected", true);
        $(".search_wrap select[name='vmlCode']").val(vmlCd).attr("selected", true);
        $(".search_wrap select[name='vehicleName']").val(customerCarId).attr("selected", true);
        $(".sv_etc_button").attr("disabled", false).removeClass("disabled_button");
    }
});

function search() {
    const varCd = $("#varCodeList").val();
    const vmlCd = $("#vmlCodeList").val();
    const customerCarId = $("#vehicleNoList").val();

    let result = selectCheck(varCd, vmlCd, customerCarId);

    if(result === true) {
        $.ajax({
            url: "/getVarCodeNm",
            data: {varCdNm: varCd, vmlCd : vmlCd, customerCarId: customerCarId},
            type: "GET",
            cache: false,
            success: function(data) {
                if (data != null) {
                    const varCdNm = data;
                    location.href = "/views/sameVehicle?varCdNm=" + varCdNm + "&vmlCd=" + vmlCd + "&customerCarId=" + customerCarId;
                }
            },
            error: function(result, status, error) {
                console.error("Error ", error);
            }
        })
    }
}

function changeContent(object) {
    const varCd = $("#varCodeList").val();
    const vmlCd = $("#vmlCodeList").val();
    const vehicleNo = $("#vehicleNoList").val();

    let result = selectCheck(varCd, vmlCd, vehicleNo);

    if(result === true) {
        let value = $(object).val();

        if(value == "list") { // 그래프로 전환
            $("#contentChange").text("리스트로 보기");
            $("#contentChange").val("graph");
            $("#listViewOn").hide();
            $("#graphViewOn").show();
            $("#safetyGradeButton").show();

            $("#contentChange").text("리스트로 보기");
            $("#contentChange").val("graph");
            $("#listViewOn").hide();
            $("#graphViewOn").show();
            $("#safetyGradeButton").show();

            getSvChart(vmlCd, vehicleNo, "health");
            getSvChart(vmlCd, vehicleNo, "btPred");
            getSvChart(vmlCd, vehicleNo, "std");
            getSvChart(vmlCd, vehicleNo, "chargePattern");

            if(noneGraphPopup === true) {
                confirmPopup("조건에 해당하는 그래프가 없습니다.\n다시 조회해주세요.",1,"reopen", "read", "svGraph");
            } else {
                $("#contentChange").text("리스트로 보기");
                $("#contentChange").val("graph");
                $("#listViewOn").hide();
                $("#graphViewOn").show();
                $("#safetyGradeButton").show();
            }
        } else { // 리스트로 전환
            $("#contentChange").text("그래프로 보기");
            $("#contentChange").val("list");
            $("#listViewOn").show();
            $("#graphViewOn").hide();
            $("#safetyGradeButton").hide();
        }
    }
}

function searchSameTypeVehicleData() {
    const varCd = $("#varCodeList").val();
    const vmlCd = $("#vmlCodeList").val();
    const vehicleNo = $("#vehicleNoList").val();

    let result = selectCheck(varCd, vmlCd, vehicleNo);

    if(result === true) {
        $.ajax({
            url: "/findCustomerIdAndCarYear",
            data: {vmlCd, vehicleNo},
            type: "GET",
            cacha: false,
            success: function(response) {
                location.href = "/views/sameTypeVehicle/?vmlCd="+vmlCd+"&carYear="+response.carYear+"&customerId="+response.customerId;
            }
        })
    }
}

// ┌─────────────────────────── click 이벤트 ───────────────────────────┐
/*
window.onload = function () {
    var search = document.getElementById("searchSend"); // 조회 버튼 클릭
    var contentChange = document.getElementById("contentChange"); // 그래프로 보기 버튼 클릭
    var sameTypeVehicleMove = document.getElementById("sameTypeVehicleMove"); // 동종 차량 비교 버튼 클릭

    // ┌─────────────────────────── 조회 ───────────────────────────┐
    /!*
    search.addEventListener("click", function () {
        console.log("----------------------------------------------------")

        varCd = document.getElementById("varCodeList").value;
        vmlCd = document.getElementById("vmlCodeList").value;
        vehicleNo = document.getElementById("vehicleNoList").value;

        let result = selectCheck(varCd, vmlCd, vehicleNo);

        if(result === true) {
            // location.href = '/sameVehicleList/' + varCd + "/" + vmlCd + "/" + vehicleNo;

            $.ajax({
                url: "/sameVehicleList",
                data: {varCdNm: varCd, vmlCd : vmlCd, vehicleNo: vehicleNo},
                type: "GET",
                cache: false,
                success: function(data) {
                    if (data != null) {
                        const varCdNm = data;
                        location.href = "/sameVehicleList?varCdNm=" + varCdNm + "&vmlCd=" + vmlCd + "&vehicleNo=" + vehicleNo;
                    }
                },
                error: function(result, status, error) {
                    console.error("Error ", error);
                }
            })
        }
    })
    *!/

    // ┌─────────────────────────── 리스트 & 그래프 전환 ───────────────────────────┐
    /!*contentChange.addEventListener("click", function () {
        let result = selectCheck(varCd, vmlCd, vehicleNo);

        if(result === true) {
            let value = document.getElementById("contentChange").value;
            if(value == "list") { // 그래프로 전환
                if(noneGraphPopup === true) {
                    confirmPopup("조건에 해당하는 그래프가 없습니다.\n다시 조회해주세요.",1,"reopen", "read", "svGraph");
                } else {
                    $("#contentChange").text("리스트로 보기");
                    $("#contentChange").val("graph");
                    $("#listViewOn").hide();
                    $("#graphViewOn").show();
                    $("#safetyGradeButton").show();
                }
            } else { // 리스트로 전환
                $("#contentChange").text("그래프로 보기");
                $("#contentChange").val("list");
                $("#listViewOn").show();
                $("#graphViewOn").hide();
                $("#safetyGradeButton").hide();
            }
        }
    })*!/

    // ┌─────────────────────────── 동종 차량 비교 버튼 클릭 ───────────────────────────┐
    /!*sameTypeVehicleMove.addEventListener("click", function () {
        let result = selectCheck(varCd, vmlCd, vehicleNo);

        if(result === true) {
            $.ajax({
                url: "/findCustomerIdAndCarYear",
                data: {vmlCd, vehicleNo},
                type: "GET",
                cacha: false,
                success: function(response) {
                    location.href = "/views/sameTypeVehicle/?vmlCd="+vmlCd+"&carYear="+response.carYear+"&customerId="+response.customerId;
                }
            })
        }
    })*!/
}
*/

// ┌─────────────────────────── 셀렉 박스 체크 ───────────────────────────┐
function selectCheck(varCd, vmlCd, vehicleNo) {
    let result = false;

    if(varCd === "none") {
        confirmPopup("차량 제조사를 선택해주세요.",1,"reopen", "read", "sameVehicle");
    } else if(vmlCd === "none") {
        confirmPopup("차량 모델을 선택해주세요.",1,"reopen", "read", "sameVehicle");
    } else if(vehicleNo === "none") {
        confirmPopup("차량 번호를 선택해주세요.", 1, "reopen", "read", "sameVehicle");
    } else {
        result = true;
    }

    return result;
}


function selectVarCode(object) {
    let varCdNm = $(object).val();
    let vmlCodeSelect = $(object).nextAll("select:first");
    clearSelectOption(object);

    if(varCdNm != "none") {
        $.ajax({
            url: "/getVmlCode/" + varCdNm ,
            data: null,
            type: "GET",
            cache: false,
        }).done(function(fragment) {
            // $("#vmlCode").replaceWith(fragment);
            vmlCodeSelect.replaceWith(fragment);
        });
    }
}

function selectVmlCode(object) {
    let varCdNm = $(object).prevAll("select:first").val();
    let vmlCd = $(object).val();
    let vehicleNoSelect = $(object).nextAll("select:first");
    clearSelectOption(object);

    if( varCdNm != "none" && vmlCd != "none") {
        $.ajax({
            url: "/getVehicleNo/" + varCdNm + "/" + vmlCd ,
            data: null,
            type: "GET",
            cache: false,
        }).done(function(fragment) {
            // $("#vehicleNoList").replaceWith(fragment);
            vehicleNoSelect.replaceWith(fragment);
        });
    }
}

function urlControl(url) {
    let query = url;
    let item = "";
    let count = 0;
    let itemResult = [];
    for(let i = decodeURI(query).length; i >= 0; i--) {
        if(decodeURI(query).slice((i*-1), (i*-1)+1) == '/') {
            itemResult[count] = item;
            item = "";
            count++;
        } else {
            if(i == 0) {
                item += decodeURI(query).slice(-1);
            } else {
                item += decodeURI(query).slice((i*-1), (i*-1)+1);
            }
        }
        if(i==0) {
            itemResult[count] = item;
            item = "";
            count = 0;
        }
    }
    return itemResult;
}

function openSafetyPopup() {

    // 충전 정보 입력
    chargeData();

    // 안전도 등급 출력
    const sohSafety = safetySoh();
    const slopeSafety = safetySlope();
    const stdSafety = safetyStd();
    const chargePatternSafety = safetyChargePattern();
    safetyGrade(sohSafety, slopeSafety, stdSafety, chargePatternSafety);
    
    $("#safetyWrap").show();
    $("#safetyWrap .one_button_wrap").show();

    $(".btn_close").on("click", function (e) {
        e.preventDefault();
        $("#safetyWrap td[id]").text('');
        $("#safetyScore").text('');
        $("#safetyGrade").text('');
        $("#safetyWrap").hide();

        $("#safetyGrade").removeClass("font_green");
        $("#safetyGrade").removeClass("font_orange");
        $("#safetyGrade").removeClass("font_red");
    });



}

function safetySoh() {
    let sohSafety;
    let sohGrade;
    const soh = $("#recentSoh").val();
    if (soh >= 85) {
        sohSafety = 2;
        sohGrade = "안전";
    } else if (soh >= 80) {
        sohSafety = 1;
        sohGrade = "주의";
    } else {
        sohSafety = 0;
        sohGrade = "위험";
    }

    $("#sohValue").text(soh);
    $("#sohSafetyScore").text(sohSafety);
    $("#sohSafetyGrade").text(sohGrade);
    $("#sohSafetyResult").text((sohSafety - 1) / 2);

    return sohSafety;
}

function safetySlope() {
    let slopeSafety;
    let slopeGrade;

    const slope = $("#slope").val() * -1; // 기울기 양수로 만들기

    if (2 >= slope ) {
        slopeSafety = 2;
        slopeGrade = "안전";
    } else if (2.5 >= slope && slope > 2) {
        slopeSafety = 1;
        slopeGrade = "주의";
    } else if (slope > 2.5) {
        slopeSafety = 0;
        slopeGrade = "위험";
    }

    /*
    const slope = $("#slope").val();
    if ( -2 - slope <= 0) { // 기준 기울기(-2)보다 작은 기울기 : 안전
        slopeSafety = 2;
        slopeGrade = "안전";
    } else if ( -2.5 - slope <= 0) { // 기준 기울기(-2.5)보다 작은 기울기 : 주의
        slopeSafety = 1;
        slopeGrade = "주의";
    } else { // -2.5보다 큰 기울기는 위험
        slopeSafety = 0;
        slopeGrade = "위험";
    }
    */

    $("#slopeValue").text(slope);
    // $("#slopeValue").text(Math.abs(slope));
    $("#slopeSafetyScore").text(slopeSafety);
    $("#slopeSafetyGrade").text(slopeGrade);
    $("#slopeSafetyResult").text((slopeSafety - 1) / 2);

    return slopeSafety;
}

function safetyStd() {
    let stdSafety;
    let stdGrade;

    const std = $("#std").val();
    if (std <= 0.26) {
        stdSafety = 2;
        stdGrade = "안전";
    } else if (std <= 0.30) {
        stdSafety = 1;
        stdGrade = "주의";
    } else {
        stdSafety = 0;
        stdGrade = "위험";
    }

    $("#sdtValue").text(std);
    $("#sdtSafetyScore").text(stdSafety);
    $("#sdtSafetyGrade").text(stdGrade);
    $("#sdtSafetyResult").text((stdSafety - 1) / 2);

    return stdSafety;
}

function safetyChargePattern() {
    let chargePatternSafety;
    let chargePatternGrade;

    const chargePatternValue = Number($("#chargePattern").val());

    if (chargePatternValue <= 3) {
        chargePatternSafety = 2;
        chargePatternGrade = "안전";
    } else if (chargePatternValue < 20) {
        chargePatternSafety = 1;
        chargePatternGrade = "주의";
    } else {
        chargePatternSafety = 0;
        chargePatternGrade = "위험";
    }

    $("#chargePatternValue").text(chargePatternValue);
    $("#chargePatternSafetyScore").text(chargePatternSafety);
    $("#chargePatternSafetyGrade").text(chargePatternGrade);
    $("#chargePatternSafetyResult").text((chargePatternSafety - 1) / 2);

    return chargePatternSafety;
}

function safetyGrade(sohSafety, slopeSafety, stdSafety, chargePatternSafety) {
    let safetyTotalGrade;

    const minScore = 0;
    const maxScore = 8;

    const safetyScore = Number(((sohSafety + slopeSafety + stdSafety + chargePatternSafety) - minScore) / (maxScore - minScore)).toFixed(3);

    if (sohSafety == 0 || slopeSafety == 0 ) {
        safetyTotalGrade = '위험';
        $("#safetyGrade").addClass("font_red");
    } else {
        if (safetyScore >= 0.8) {
            safetyTotalGrade = '안전';
            $("#safetyGrade").addClass("font_green");
        } else if (safetyScore >= 0.3) {
            safetyTotalGrade = '주의';
            $("#safetyGrade").addClass("font_orange");
        } else {
            safetyTotalGrade = '위험';
            $("#safetyGrade").addClass("font_red");
        }
    }

    $("#safetyScore").text(safetyScore);
    $("#safetyGrade").text(safetyTotalGrade);
}


function chargeData() {
    let query = window.location.search;
    let param = new URLSearchParams(query);

    const vehicleBrand = param.get("varCdNm");
    const vehicleModel = $("#svFirstList p.text.vehicle_model").text();
    const vehicleNumber = $("#svFirstList p.text.vehicle_number").text();
    const vehicleYear = $("#svFirstList p.text.vehicle_year").text();

    const firstCharge = dateFormat($("#firstCharge").val());
    const lastCharge = dateFormat($("#lastCharge").val());
    const chargeCount = $("#chargeCount").val();

    $(".table_content .vehicle_brand").text(vehicleBrand);
    $(".table_content .vehicle_model").text(vehicleModel);
    $(".table_content .vehicle_number").text(vehicleNumber);
    $(".table_content .vehicle_year").text(vehicleYear);

    $(".table_content .first_charge").text(firstCharge);
    $(".table_content .last_charge").text(lastCharge);
    $(".table_content .charge_count").text(chargeCount);

}

function dateFormat(chargeDate) {
    const date = new Date(chargeDate);
    const yyyy = date.getFullYear();
    const MM = String(date.getMonth() + 1).padStart(2, '0'); // 월은 0부터 시작
    const dd = String(date.getDate()).padStart(2, '0');
    const hh = String(date.getHours()).padStart(2, '0');
    const mm = String(date.getMinutes()).padStart(2, '0');
    const ss = String(date.getSeconds()).padStart(2, '0');

    return `${yyyy}-${MM}-${dd} ${hh}:${mm}:${ss}`;
}