function getSohData(testId) {
    const startTime = new Date().getTime(); // 시작 시간(ms)

    $("#loaderWrap").show();

    $.ajax({
        url: "/getSohData/" + testId,
        type: "get",
        async: true,
        cache: false,
        success: function(data) {
            $("#loaderWrap").hide();
            $("#testReportWrap").show();
            $("#testReportWrap .one_button_wrap").show();

            $(".btn_close").on("click", function (e) {
                e.preventDefault();
                $("#testReportWrap").hide();
            });

            if (data != null) {
                const maskedVehicleNumber = data.vehicleNumber.replace(/[0-9]{4}$/, '****');

                let modal = $('#testReportWrap');
                modal.find('.vehicle_brand').text(data.brand);
                modal.find('.vehicle_model').text(data.model);
                modal.find('.vehicle_year').text(data.year);
                modal.find('.vehicle_number').text(maskedVehicleNumber);
                modal.find('#sohValue').text(data.result);
                modal.find('#elapsedTime').text(data.elapsedTime);
            }

            const endTime = new Date().getTime(); // 종료 시간(ms)
            const elapsedSec = ((endTime - startTime) / 1000).toFixed(2); // 초 단위, 소수점 2자리
            console.log("건강도 평가 소요 시간 : " + elapsedSec + "초");
        },
        error: function(result, status, error) {
            console.error("Error ", error);
        }
    });
}