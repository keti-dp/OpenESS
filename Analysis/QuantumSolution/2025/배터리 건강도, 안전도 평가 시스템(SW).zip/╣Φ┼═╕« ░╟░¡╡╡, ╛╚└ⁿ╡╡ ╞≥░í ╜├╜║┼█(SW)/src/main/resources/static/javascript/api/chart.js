// chart.js

document.addEventListener('DOMContentLoaded', function() {
    const data = [
        [1, 95.89],
        [2, 97.64],
        [3, 96.89],
        [4, 97.48],
        [5, 96.62],
        [6, 97.32],
        [7, 95.8],
        [8, 98.43],
        [9, 94.6],
        [10, 94.25],
        [11, 93.3],
        [12, 93.44],
        [13, 93.64],
        [14, 93.01],
        [15, 93.72],
        [16, 93.29],
        [17, 94.68],
        [18, 93.58],
        [19, 94.05],
        [20, 95.49],
        [21, 90.95],
        [22, 93.54],
        [23, 89.11],
        [24, 93.98],
        [25, 93.06],
        [26, 93.52],
        [27, 93.56],
        [28, 93.09],
        [29, 93.66],
        [30, 92.54],
        [31, 93.69],
        [32, 94.34],
        [33, 93.34],
        [34, 93.47],
        [35, 93.84],
        [36, 92.36],
        [37, 92.53],
        [38, 92.51],
        [39, 93.22],
        [40, 94.59],
        [41, 93.52],
        [42, 93.31],
        [43, 92.07],
        [44, 92.65],
        [45, 90.83],
        [46, 94.37],
        [47, 93.77],
        [48, 93.14],
        [49, 92.58],
        [50, 94.67],
        [51, 93.91],
        [52, 94.11],
        [53, 93.93],
        [54, 92.87],
        [55, 94.01],
        [56, 94.22],
        [57, 95.32],
        [58, 93.83],
        [59, 93.94],
        [60, 95.54],
        [61, 92.61],
        [62, 93.75],
        [63, 92.73],
        [64, 92.69],
        [65, 92.56],
        [66, 93.4],
        [67, 93.93],
        [68, 92.92],
        [69, 93.31],
        [70, 93.07],
        [71, 92.67],
        [72, 93.5]
    ];
    const degree = 3;

    // 회귀 계수 계산
    const coefficients = polynomialRegression(data, degree);

    // 회귀선 데이터 생성
    const regressionLine = [];
    for (let i = 0; i <= coefficients.length; i += 0.1) {
        let y = 0;
        for (let j = 0; j <= degree; j++) {
            y += coefficients[j] * Math.pow(i, j);
        }
        regressionLine.push([i, y]);
    }

    // Highcharts를 사용하여 그래프 그리기
    Highcharts.chart('container', {
        title: {
            text: 'Nonlinear Regression'
        },
        xAxis: {
            title: {
                text: 'X'
            }
        },
        yAxis: {
            title: {
                text: 'Y'
            }
        },
        series: [{
            name: 'Data Points',
            type: 'scatter',
            data: data
        }, {
            name: 'Regression Line',
            type: 'line',
            data: regressionLine,
            color: 'red'
        }]
    });
});