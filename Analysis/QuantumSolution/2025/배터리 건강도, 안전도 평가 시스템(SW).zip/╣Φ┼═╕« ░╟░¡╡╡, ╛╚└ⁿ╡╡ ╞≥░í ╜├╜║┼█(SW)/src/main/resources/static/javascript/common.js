$(document).ready(function() {
    $(".gnb > li > a").on("click", function() {
        localStorage.removeItem("menuIndex");
    });

    let menuIndex = localStorage.getItem("menuIndex");
    if( menuIndex == null ) {
        menuIndex = 0;
        localStorage.setItem("menuIndex", menuIndex);
    }

    $('.gnb .depth2 li').on('mouseenter', () => {
        $('.depth2').parent().addClass("hover_disable");
    });

    $('.gnb .depth2 li').on('mouseleave', () => {
        $('.depth2').parent().removeClass("hover_disable");
    });

});

function openSubMenu(object) {
    if ($(object).hasClass("active")) {
        $(object).removeClass("active");
        $(object).next().removeClass("active").children("li").addClass("hide");
    } else {
        $(object).addClass("active");
        $(object).next().addClass("active").children("li").removeClass("hide");
    }
}

/* select 옵션이 없을 경우 첫번째 옵션을 "목록 없음"으로 출력 */
function changeFirstOption(fragment) {
    let optionCount = fragment.match(/<option value=/g).filter(function(item) { return item !== ''; }).length;
    let fragmentArray = fragment.split("\n");

    if  (optionCount == 1) {
        fragmentArray[1] = "<option value='none'>목록 없음</option>";
    } else {
        fragmentArray[1] = "<option value='none'>선택하세요.</option>";
    }

    fragment = fragmentArray.join("\n");

    return fragment;
}

function clearSelectOption(object) {
    $(object).nextAll("select").each(function(index, item) {
        $(item).children("option:first").attr("selected", true);
        $(item).children("option:not(:first)").remove();
    });
}


function sameVehicleReady() {
/*
    let varCdNm = "none";
    let vmlCd = "none";
    let vehicleNo = "none";
    location.href = '/sameVehicleList/' + varCdNm + "/" + vmlCd + "/" + vehicleNo;
*/
}
