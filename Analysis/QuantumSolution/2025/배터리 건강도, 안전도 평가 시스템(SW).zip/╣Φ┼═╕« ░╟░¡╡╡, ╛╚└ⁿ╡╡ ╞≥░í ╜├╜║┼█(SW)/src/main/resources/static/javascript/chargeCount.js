function redirectSameVehiclePage(object) {
    const vmlCd = $(object).find('td[name="vmlCd"]').text().trim();
    const customerId = $(object).find('input[name="customerId"]').val();

    $.ajax({
        url: "/redirect",
        data: {vmlCd : vmlCd, customerId: customerId},
        type: "GET",
        cache: false,
        success: function(data) {
            if (data != null) {
                data = JSON.parse(data);
                const varCdNm = data.varCd;
                const customerCarId = data.customerCarId;
                location.href = "/sameVehicleList?varCdNm=" + varCdNm + "&vmlCd=" + vmlCd + "&customerCarId=" + customerCarId;
            }
        },
        error: function(result, status, error) {
            console.error("Error ", error);
        }
    })
}