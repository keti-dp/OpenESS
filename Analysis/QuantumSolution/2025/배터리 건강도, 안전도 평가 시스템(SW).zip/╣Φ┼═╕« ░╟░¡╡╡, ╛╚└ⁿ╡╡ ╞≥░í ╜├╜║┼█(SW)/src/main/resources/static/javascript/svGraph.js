$(document).ready(function () {
});

let noneGraphPopup = false;

// ┌─────────────────────────── Graph ───────────────────────────┐
function getSvChart(vmlCd, vehicleNo, name) {

    noneGraphPopup = false;

    $.ajax({
        url: "/views/getSvChart/" + name,
        type: "POST",
        data: {vmlCd, vehicleNo},
        async: true,
        cache: false,
        success: function(data) {
            if (data != null) {
                data = JSON.parse(data);

                const vehicleNumber = data.vehicleNumber;

                if (data.listSize != 0) {
                    if(name == "health") {
                        healthChart(data, vmlCd, vehicleNumber);
                    } else if (name == "btPred") {
                        btPredChart(data, vehicleNumber, name);
                    } else if (name == "std") {
                        stdChart(data, vehicleNumber);
                    } else {
                        chargePatternChart(data, vehicleNumber);
                    }
                } else {
                    noneGraphPopup = true;
                }
                $(".sv_chart_content").show().css("display", "inline-block");
            }
        },
        error: function(result, status, error) {
            console.error("Error ", error);
        }
    });
}

function healthChart(data, vmlCd, vehicleNo) {
    vehicleNo = vehicleNo.replace(/[0-9]{4}$/, "****");
    let size = data.nonLinearPoint.length;
    let lastSoh = data.nonLinearPoint[size-1];
    // 차트 옵션 설정

    let healthChartOptions = {
        chart: {
            renderTo: 'healthChart',
            height: 290, //$("#healthChart").height(),
            zoomType: "xy"
        },
        title: {text: data.carModel + ' / ' + vehicleNo + ' - 건강도 추이 분석'},
        xAxis: [{
            categories: data.indexList,
            // tickInterval: 50,
            labels: {enabled: true},
            crosshair: true
        }],
        yAxis: [{
            title: {
                text: 'SoH[%]',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            labels: {
                format: '{value:,.1f}',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            max:100,
            // min: 86,
            min:lastSoh-2,
            opposite: false
        }],
        series: [{
            name: "SoH",
            type: 'scatter',
            data: data.nonLinearPoint,
            marker: {enabled: true,
                radius: 3 // 마커의 반지름을 5픽셀로 설정
            },
            color: 'rgb(30, 65, 116)'
        }, {
            name: "배터리 건강도 추이",
            type: 'spline',
            data: data.nonLinearLine,
            marker: {enabled: false},
            color: 'rgb(221, 169, 75)'
        }],
        credits: {enabled: false},
        legend: {enabled: true}
    };

    healthChartOptions = setChartTooltipOptions(healthChartOptions, "health");

    // Highcharts 옵션 설정
    /*    Highcharts.setOptions({
        lang: {
            thousandsSep: ','
        }
    });*/

    // 차트 그리기
    chart = new Highcharts.chart('healthChart', healthChartOptions);
    // getSvChart(vmlCd, vehicleNo, "btPred");
}

function btPredChart(data, vehicleNo, name) {
    vehicleNo = vehicleNo.replace(/[0-9]{4}$/, "****");
    let first = data.sohChartLine[0][1]; // 라인 첫 soh
    let soh = data.sohChartLine[data.sohChartLine.length-1][1]; // 라인 마지막 soh
    let value;
    if(data.sohChartPoint.length != 1) {
        let minusValue = first - soh; // 데이터 처음부터 마지막까지의 총 감소값
        value = minusValue / (data.sohChartLine.length-1); // 하루당 감소되는 값
        soh = data.sohChartLine[data.sohChartLine.length-1][1]; // 데이터 마지막 soh값
    } else {
        value = 0.03;
        soh = data.sohChartPoint[0];
    }

    let indexList = 0;
    let indexListMessage = "";

    // 데이터 평균 감소값으로 예측 계산하여 soh가 80이 될때까지 라인 데이터를 추가, 그 후 남은 예상 수명을 메세지에 표시
    while(true) {
        if(soh < 80 || soh >= 100) {
            indexList = data.indexList.length-1;
            let year = indexList / 365;
            if(year.toFixed(0) >= 1) {
                indexListMessage = "해당 배터리의 예상 수명은 약 " + year.toFixed(0) + "년 이상입니다.";
            } else {
                indexListMessage = "해당 배터리의 예상 수명은 약 1년 이하입니다.";
            }
            break;
        } else {
            soh -= value;
            if(data.sohChartLine[data.sohChartLine.length-1][1] != 0) { // 0값 제거
                data.sohChartLine[data.sohChartLine.length] = [];
            }
            data.sohChartLine[data.sohChartLine.length-1][0] = data.sohChartLine.length-1;
            data.sohChartLine[data.sohChartLine.length-1][1] = soh;
            data.indexList[data.indexList.length] = data.indexList.length;
        }
    }

    let yearValue = 10;
    let sohDecrease = -20;
    let slope = sohDecrease / (365 * yearValue);

    let fmPredData;
    for (let i = 0; i < data.indexList.length; i++) {
        fmPredData = (slope * i) + first;
        data.fmPredData[i] = fmPredData;
    }
    const lastSoh = [...data.sohChartPoint].reverse().find(v => v !== null);
    const lastSohIndex = data.sohChartPoint.findLastIndex(v => v !== null);

    let xAxisLength = data.indexList.length;
    let isNearEnd = lastSohIndex > xAxisLength * 0.98;

    // 차트 옵션 설정
    let btPredChartOptions = {

        chart: {
            renderTo: 'btPredChart',
            height: 290, // $("#btPredChart").height(),
            zoomType: "xy"
        },
        title: {text: data.carModel + ' / ' + vehicleNo + ' - RUL 예측'},
        subtitle: {
            text: '',
            style: {fontSize: '14px'},
            align: 'right'
        },
        xAxis: [{
            categories: indexList,
            tickInterval: 50,
            labels: {enabled: true},
            crosshair: true,
            plotLines: [{   // weight 차트에서만 작동
                color: '#FE6370',
                width: 1.3,
                value: lastSohIndex,
                // value: data.yBar,
                zIndex: 5,
                dashStyle: 'dash',
                label: {
                    text: '최근 SOH',
                    align: 'left',
                    textAlign: 'center',
                    rotation: 0, // 0이면 수평, -90이면 세로
                    x: isNearEnd ? -25 : 0,
                    y: -5,
                    style: {
                        fontWeight: 'bold',
                        color: '#FE6370',
                    }
                }
            }]
        }],
        yAxis: [{
            title: {
                text: 'SoH[%]',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            labels: {
                format: '{value:,.1f}',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            max:100,
            min: (data.yMin-10),
            opposite: false
        }],
        series: [{
            name: "SoH",
            type: 'scatter',
            data: data.sohChartPoint,
            marker: {
                enabled: true,
                radius: 3 // 마커의 반지름을 5픽셀로 설정
            },
            color: 'rgb(30, 65, 116)'
        }, {
            name: "배터리 잔여 수명 예측",
            type: 'line',
            data: data.sohChartLine,
            marker: {enabled: false},
            color: 'rgb(221, 169, 75)'
        }, {
            name: "표준 건강도 예측",
            type: 'line',
            data: data.fmPredData,
            marker: {enabled: false},
            color: 'rgb(64,116,204)'
        }/*, {
            name: '최근',
            type: 'line',
            dashStyle: 'longdash',
            data: data.yBar,
            marker: {enabled: false},
            color: '#ff0000'
        }*/],
        credits: {enabled: false},
        legend: {enabled: true}
    };

    btPredChartOptions.subtitle.text = indexListMessage;

    btPredChartOptions = setChartTooltipOptions(btPredChartOptions, "btPred");

    // 차트 그리기
    chart = new Highcharts.chart('btPredChart', btPredChartOptions);

    //  안전도 산출 -> 일단위에서 연단위로 기울기 산출(현재 일단위 -> * 365)
    //     $("#slope").val(Math.abs(data.slope * 365).toFixed(2));
    $("#slope").val((data.slope * 365).toFixed(2));
    $("#recentSoh").val(lastSoh);

    const std = data.std;
    $("#std").val(std.toFixed(2));

    $("#firstCharge").val(data.firstCharge);
    $("#lastCharge").val(data.lastCharge);
    $("#chargeCount").val(data.chargeCount);

    // getSvChart(vmlCd, vehicleNo, "std");
}

function stdChart(data, vehicleNo) {
    vehicleNo = vehicleNo.replace(/[0-9]{4}$/, "****");
    let stdChartOptions = {
        chart: {
            renderTo: 'stdChart',
            height: 290,
            zoomType: "xy"
        },
        title: {text: data.carModel + ' / ' + vehicleNo + ' - 충전편차'},
        subtitle : {
            useHTML:true,
            text:
                '<span class="green_dot">● 안전(0.26 이하)</span>' +
                '<span class="yellow_dot">● 주의(0.26 초과, 0.30 이하)</span>' +
                '<span class="red_dot">● 위험(0.30 초과)</span>',
            align: 'right',
            style: {fontSize: '14px'}
        },
        xAxis: [{
            categories: data.stdIndexList,
            labels: {enabled: true},
            crosshair: true
        }],
        yAxis: [{
            title: {
                text: '편차',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            labels: {
                format: '{value:,.2f}',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            plotLines: [
                {
                    value: data.totalStdAvg,   // 가로줄 위치
                    color: '#4074cc',              // 선 색상
                    width: 1.5,                  // 선 두께
                    dashStyle: 'Dash',         // 선 스타일 (Solid, Dash, Dot 등)
                    label: {
                        text: '충전편차 평균 : ' + data.totalStdAvg.toFixed(2),
                        align: 'right',
                        y: -20,
                        style: { color: '#4074cc' }
                    },
                    zIndex: 5
                }
                /*, {
                    value: 0.26,   // 가로줄 위치
                    color: '#DDA94BFF',              // 선 색상
                    width: 1.5,                  // 선 두께
                    dashStyle: 'Dash',         // 선 스타일 (Solid, Dash, Dot 등)
                    label: {
                        text: '0.26 이상 : 주의',
                        align: 'right',
                        y: -20,
                        style: { color: '#DDA94BFF' }
                    },
                    zIndex: 5
                }, {
                    value: 0.30,   // 가로줄 위치
                    color: '#FE6370',              // 선 색상
                    width: 1.5,                  // 선 두께
                    dashStyle: 'Dash',         // 선 스타일 (Solid, Dash, Dot 등)
                    label: {
                        text: '0.30 초과 : 위험',
                        align: 'left',
                        x: 10,
                        y: -10,
                        style: { color: '#FE6370' }
                    },
                    zIndex: 5
                }*/
            ],
            tickInterval: 0.1
        }],
        series: [{
            name: "충전편차",
            type: 'column',
            data: data.stdData,
            zones : [
                {
                    value: 0.27,
                    color: '#3ebf8b'
                },
                {
                    value: 0.31,
                    color: '#DDA94BFF'
                },
                {
                    color: '#FE6370'  // 나머지 값 (0.30 이상)
                }
            ],
            marker: {enabled: false},
            color: '#3ebf8b'
        }],
        credits: {enabled: false},
        legend: {enabled: true}
    };
    stdChartOptions = setChartTooltipOptions(stdChartOptions, "std");

    chart = new Highcharts.chart('stdChart', stdChartOptions);
    // getSvChart(vmlCd, vehicleNo, "chargePattern");
}


function chargePatternChart(data, vehicleNo) {
    vehicleNo = vehicleNo.replace(/[0-9]{4}$/, "****");
    let chargePatternChartOptions = {
        chart: {
            renderTo: 'chargePatternChart',
            type: 'pie',
            options3d: {
                enabled: true,
                alpha: 30,
                beta: 0
            }
        },
        title: {text: data.carModel + ' / ' + vehicleNo + ' - 충전습관'},
        subtitle: {
            // align: 'right',
            text: '안전 충전 범위 : 시작 SoC 20% 이상, 종료 SoC 80% 미만',
            style: {fontSize: '14px'}
        },
        accessibility: {
            point: {
                valueSuffix: '회'
            }
        },
        plotOptions: {
            pie: {
                allowPointSelect: false,
                depth: 45,
                dataLabels: {
                    style: { fontSize: '14px' },
                    inside: true,
                    distance: -10, // 중심에 더 가깝게
                    // verticalAlign: 'middle',
                    enabled: true,
                    format: '{point.name} : {point.y}회 <br> ({point.percentage:.1f}%)' // 이름 + 퍼센트
                }
            }, series: {
                animation: false
            }
        },
        series: [{
            type: 'pie',
            data: [
                {name: '비안전 충전', y: data.chargePatternData.unsafeCharge, color: '#FE6370'},
                {name: '안전 충전', y: data.chargePatternData.safeCharge, color: '#4074cc', sliced: true}
            ]}
        ],
        credits: {enabled: false},
        legend: {enabled: true}
    };

    const unsafeChargePatternRate = data.chargePatternData.unsafeChargeRate.toFixed(2);
    $("#chargePattern").val(unsafeChargePatternRate);

    chargePatternChartOptions = setChartTooltipOptions(chargePatternChartOptions, "chargePattern");

    chart = new Highcharts.chart('chargePatternChart', chargePatternChartOptions);
}


function setChartTooltipOptions(chartOptions, menu) {
    let tooltipOption = Highcharts.getOptions().tooltip;

    let replaceHeaderFormat = '{point.key}일 차';
    let replacePointFormat = '{point.y:.1f}';

    if (menu == "std") {
        replaceHeaderFormat = '{point.key}회 차';
        replacePointFormat = '{point.y:.2f}';
    } else if (menu == "chargePattern") {
        replaceHeaderFormat = '{point.key}';
        tooltipOption.pointFormat = '<b>{point.y}</b>';
        replacePointFormat = '{point.y}회 ({point.percentage:.1f}%)';
    }

    chartOptions.tooltip = {
        headerFormat: tooltipOption.headerFormat.replace('{point.key}', replaceHeaderFormat),
        pointFormat: tooltipOption.pointFormat.replace('{point.y}', replacePointFormat),
        footerFormat: tooltipOption.footerFormat,
        shared: true,
        style: {
            fontWeight: 'bold',
            fontSize: '14px'
        },
        lang: {
            thousandsSep: ','
        }
    };

    return chartOptions;
}
