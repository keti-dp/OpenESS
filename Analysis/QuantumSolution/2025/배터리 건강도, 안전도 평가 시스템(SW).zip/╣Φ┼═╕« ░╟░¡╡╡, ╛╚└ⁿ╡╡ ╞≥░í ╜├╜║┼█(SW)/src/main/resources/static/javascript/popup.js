/**
 * 등록 혹은 팝업창 닫을 때 안내 팝업창
 1. msg : 문구,
 2. num : 버튼 개수
 3. division : 구분     1) reload - 새로 고침 2) reopen - 등록 팝업창 출력 3) close : 팝업창 닫기
 4. tag : 등록, 수정, 조회, 삭제 구분     1) regist : 등록 2) update : 수정  3) read : 조회 4) delete : 삭제  5) search : report 조회
 5. menu : 각 페이지의 메뉴
 6. idNumber : 조회, 수정, 삭제하려는 formDto의 idNumber
 */

function confirmPopup(msg, num, division, tag, menu) {
    //openTagPopup('', tag, "hide", menu);

    $("#resultText").html(msg);
    $("#confirmWrap").show();
    $("#confirmWrap .one_button_wrap, #confirmWrap .two_button_wrap").hide();

    if (num == 1) {
        $("#confirmWrap .one_button_wrap").show();

        $(".btn_close").on("click", function (e) {
            e.preventDefault();
            $("#confirmWrap").hide();
            /*if (division == "reload") {
                location.reload();
            } else {
                console.log("@@@@@")
            }*/
        });
    } else {
        //openTagPopup('', tag, "hide");
        $("#confirmWrap .two_button_wrap").show();
        $(".btn_close").on("click", function () {
            $("#confirmWrap").hide();
            //closeSettingPopup();
        });

        $(".btn_confirm").on("click", function(e) {
            $("#modalConfirm .one_button_wrap").show();
            //$("#confirmWrap").hide();
        });
    }
}

function openConfirmPopup(msg) {
    $("#resultText").html(msg);
    $("#confirmWrap").show();
    $("#confirmWrap .one_button_wrap, #confirmWrap .two_button_wrap").hide();
    $("#confirmWrap .one_button_wrap").show();

    $(".btn_close").on("click", function (e) {
        e.preventDefault();
        $("#confirmWrap").hide();
    });
}