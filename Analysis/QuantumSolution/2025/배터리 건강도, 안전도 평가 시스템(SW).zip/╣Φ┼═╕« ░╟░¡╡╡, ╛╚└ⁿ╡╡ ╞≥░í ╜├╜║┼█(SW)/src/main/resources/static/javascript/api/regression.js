// regression.js

function polynomialRegression(data, degree) {
    const n = data.length;
    const X = [];
    const y = [];

    // 데이터 배열을 행렬 형태로 변환
    for (let i = 0; i < n; i++) {
        const xValue = data[i][0];
        const row = []
        for (let j = 0; j <= degree; j++) {
            row.push(Math.pow(xValue, j));
        }
        X.push(row);
        y.push(data[i][1]);
    }

    // 행렬 연산을 위한 수학적 함수들
    const math = {
        transpose: function(a) {
            return a[0].map((_, c) => a.map(r => r[c]));
        },
        multiply: function(a, b) {
            return a.map(row => b[0].map((_, i) => row.reduce((sum, _, j) => sum + row[j] * b[j][i], 0)));
        },
        inverse: function(matrix) {
            // Implement matrix inversion (for simplicity, use a library like numeric.js in production)
            return numeric.inv(matrix); // Assuming numeric.js is included
        }
    };

    // 행렬 연산을 통한 회귀 계수 계산
    const XMatrix = X;
    const yMatrix = y.map(value => [value]);
    const XTranspose = math.transpose(XMatrix);
    const XTX = math.multiply(XTranspose, XMatrix);
    const XTy = math.multiply(XTranspose, yMatrix);
    const XTXInverse = math.inverse(XTX);
    const theta = math.multiply(XTXInverse, XTy);

    // 1차원 배열로 변환하여 반환
    return theta.map(row => row[0]);
}