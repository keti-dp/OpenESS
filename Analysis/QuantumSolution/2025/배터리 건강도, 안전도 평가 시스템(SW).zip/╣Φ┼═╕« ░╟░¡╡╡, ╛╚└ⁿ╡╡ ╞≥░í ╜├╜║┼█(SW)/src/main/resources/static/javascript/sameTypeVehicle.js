let chart;

$(document).ready(function () {
    $(".gnb .same_type").parent().addClass("active");
    let query = window.location.search;
    let param = new URLSearchParams(query);

    let vmlCd = param.get("vmlCd") == null ? "none" : param.get("vmlCd");
    let carYear = param.get("carYear") == null ? "none" : param.get("carYear");
    let customerId = param.get("customerId") == null ? "none" : param.get("customerId");

    let paramValueArray = Array.from(param.values());
    let paramFlag = (!(paramValueArray.includes("undefined") || paramValueArray.includes("none")));

    if (param.size > 0) {
        if (param.size == 3 && paramFlag) {
            $(".table_content_wrap").removeClass("fixed_height");

            let paramArray = Array.from(param);
            for (let i = 0; i < paramArray.length; i++) {
                let key = paramArray[i][0];
                let value = paramArray[i][1];

                $(".search_wrap select[name='" + key + "']").val(value).attr("selected", true);
            }
        } else {
            if (vmlCd != null) {
                $(".search_wrap select[name='vmlCd']").val(vmlCd).attr("selected", true);
                getCarYearList($(".search_wrap select[name='vmlCd']")), function () {
                    if (carYear != "none") {
                        $(".search_wrap select[name='carYear']").val(carYear).attr("selected", true);
                        getVehicleNumber($(".search_wrap select[name='carYear']")), function () {
                            $(".search_wrap select[name='customerId']").val(customerId).attr("selected", true);
                        };
                    }
                };
            }

            let msg = "";

            if (vmlCd == "none") {
                msg = "차종을";
            } else if (carYear == "none") {
                msg = "연식을";
            } else {
                msg = "차량 번호를";
            }

            openConfirmPopup(msg + " 선택해주세요.");
        }
    }
});

function getCarYearList(object) {
    let vmlCd = $(object).val();
    let carYearSelect = $(object).nextAll("select:first");

    clearSelectOption(object);

    if( vmlCd != "none") {
        $.ajax({
            url: "/views/sameTypeVehicle/getCarYearList/" + vmlCd ,
            data: String(vmlCd),
            type: "GET",
            cache: false,
        }).done(function(fragment) {
            fragment = changeFirstOption(fragment);
            carYearSelect.replaceWith(fragment);
        });
    }
}


function getVehicleNumber(object) {
    let vmlCd = $(object).prevAll("select:first").val();
    let carYear = $(object).val();
    let vehicleNumberSelect = $(object).nextAll("select:first");

    clearSelectOption(object);

    if( vmlCd != "none" && carYear != "none") {
        $.ajax({
            url: "/views/sameTypeVehicle/getVehicleNumber/" + vmlCd + "/" + carYear ,
            data: {"vmlCd" : vmlCd, "carYear" : carYear},
            type: "GET",
            cache: false,
        }).done(function(fragment) {
            fragment = changeFirstOption(fragment);
            vehicleNumberSelect.replaceWith(fragment);
        });
    }
}

function getData() {
    let requestUrl = "/views/sameTypeVehicle";
    let params = [];
    let msg = "";
    let selectFlag = true;

    $(".search_wrap select").each(function (index, item) {
        let selectName = $(item).prev().text();
        if ($(item).val() == "none") {
            msg = selectName + ((selectName == "차종" || selectName == "연식") ? "을" : "를") + " 선택해주세요.";
            selectFlag = false;
            openConfirmPopup(msg);
            return false;
        } else {
            params.push($(item).attr("name") + "=" + $(item).val());
        }
    });

    if (selectFlag) {
        if (params.length > 0) {
            requestUrl += "?" + params.join("&");
        }

        location.href = requestUrl;
    }
}

function toggleChart(object) {

    if ($(".content h2").text() == "동종 차량/연식 비교 조회") {
        $(".content h2").text("동종 차량/연식 데이터 비교");
        $(object).text("그래프로 보기");
        $(".list_content").show();
        $(".chart_content").hide();
        $(".btn_search").val("list")
    } else {
        $(".content h2").text("동종 차량/연식 비교 조회");
        $(object).text("리스트로 보기");
        $(".chart_content").show();
        $(".list_content").hide();
        $(".btn_search").val("chart")
        requestChartData(object);
    }
}

function requestChartData(object) {
    let sameTypeVehicleSearchFormDto = $(object).parent().serialize();

    $.ajax({
        url: "/views/sameTypeVehicle/chart",
        type: "POST",
        data: sameTypeVehicleSearchFormDto,
        async: true,
        cache: false,
        success: function(data) {
            if (data != null) {
                data = JSON.parse(data);
                if (data.listSize != 0) {
                    drawChart(data);
                }
            }
        },
        error: function(result, status, error) {
            console.error("Error ", error);
        }
    });
}

function drawChart(data) {
    // 차트 옵션 설정
    let chartOptions = {
        chart: {
            renderTo: 'container',
            height: $("#container").height(),
            zoomType: "xy"
        },
        title: {text: data.vmlCd + ' / ' + data.vehicleNumber + ' - 동종 차량 SoH 비교'},
        subtitle: {
            text: '',
            style: {fontSize: '14px'},
            align: 'right'
        },
        xAxis: [{
            categories: data.indexList,
            labels: {enabled: true},
            tickInterval: 50,
            crosshair: true
        }],
        yAxis: [{
            title: {
                text: 'SoH[%]',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            labels: {
                format: '{value:,.1f}',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            max:100,
            opposite: false
        }],
        series: [{
            name: "조회 차량 SoH",
            type: 'scatter',
            data: data.searchCarList,
            marker: {enabled: true}
        }, {
            name: "동종 차량 SoH",
            type: 'scatter',
            data: data.notSearchCarList,
            marker: {enabled: true}
        }, {
            name: "조회 차량 SoH 추세선",
            type: 'line',
            data: data.searchCarRegressionJsonArray,
            marker: {enabled: false}
        }, {
            name: "동종 차량 SoH 추세선",
            type: 'line',
            data: data.notSearchCarRegressionJsonArray,
            marker: {enabled: false}
        }],
        credits: {enabled: false},
        legend: {enabled: true}
    };

    if (data.indexList.length < 200) {
        chartOptions.xAxis = {
            tickInterval: 10,
            tickWidth: 0
        }
    }

    if (data.sohPercentageDiff != undefined) {
        chartOptions.subtitle.text += '조회한 차량의 SoH는 동종 차량의 평균 SoH 대비 약 <span class="highchart_subtitle">' + data.sohPercentageDiff + '%</span> 입니다.';
    } else {
        chartOptions.subtitle.text += '동종 차량의 충전 데이터가 없습니다.';
    }

    chartOptions = setChartTooltipOptions(chartOptions);

    // Highcharts 옵션 설정
    Highcharts.setOptions({
        lang: {
            thousandsSep: ','
        }
    });

    // 차트 그리기
    chart = new Highcharts.chart('container', chartOptions);
}

function setChartTooltipOptions(chartOptions) {
    let tooltipOption = Highcharts.getOptions().tooltip;

    chartOptions.tooltip = {
        headerFormat: tooltipOption.headerFormat.replace('{point.key}', '{point.key}일 후'),
        pointFormat: tooltipOption.pointFormat.replace('{point.y}', '{point.y:.1f}'),
        footerFormat: tooltipOption.footerFormat,
        shared: false,
        style: {
            fontWeight: 'bold',
            fontSize: '14px'
        }
    };

    return chartOptions;
}