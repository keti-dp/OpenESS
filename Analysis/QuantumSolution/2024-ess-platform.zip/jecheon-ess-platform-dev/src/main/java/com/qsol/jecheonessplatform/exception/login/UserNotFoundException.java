package com.qsol.jecheonessplatform.exception.login;

import com.qsol.jecheonessplatform.exception.GlobalException;

public class UserNotFoundException extends GlobalException {

    private static final String MESSAGE = "User Not Found.";

    public UserNotFoundException() {
        super(MESSAGE);
    }

    @Override
    public int getStatusCode() {
        return 404;
    }
}
