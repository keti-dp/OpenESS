package com.qsol.jecheonessplatform.login.service;

import com.qsol.jecheonessplatform.auth.provider.JwtProvider;
import com.qsol.jecheonessplatform.exception.login.UserNotFoundException;
import com.qsol.jecheonessplatform.login.dto.request.SignInRequest;
import com.qsol.jecheonessplatform.login.dto.request.SignUpRequest;
import com.qsol.jecheonessplatform.login.dto.response.ApiResponse;
import com.qsol.jecheonessplatform.login.dto.response.SignInResponse;
import com.qsol.jecheonessplatform.login.dto.response.SignUpResponse;
import com.qsol.jecheonessplatform.common.entity.login.Userinfo;
import com.qsol.jecheonessplatform.login.repository.LoginRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import static javax.servlet.http.HttpServletResponse.*;

@Slf4j
@Transactional(readOnly = true)
@RequiredArgsConstructor
@Service
public class LoginService {
    private final JwtProvider jwtProvider;
    private final LoginRepository loginRepository;
    private final PasswordEncoder passwordEncoder;

    public ApiResponse<SignInResponse> signIn(SignInRequest request, HttpServletRequest rq) { // 로그인
        Userinfo userinfo = loginRepository.findByUsername(request.getUsername()).orElseThrow(UserNotFoundException::new);
        String message = "success";

        if (!passwordEncoder.matches(request.getPassword(), userinfo.getPassword())) {
//            throw new PasswordsNotMatchException();
            message = "error";
            return new ApiResponse<>(SC_BAD_REQUEST, new SignInResponse(userinfo, message));
        } else {
            String token = jwtProvider.generateToken(userinfo.getUsername());
            log.info("[TOKEN]={}", token);
            HttpSession session = rq.getSession();
            session.setAttribute("username", userinfo.getUsername());

            return new ApiResponse<>(SC_OK, new SignInResponse(userinfo, message));
        }
    }

    @Transactional
    public ApiResponse<SignUpResponse> signUp(SignUpRequest request) { // 회원가입
        Userinfo userinfo = Userinfo.builder()
                .username(request.getUsername())
                .password(passwordEncoder.encode(request.getPassword()))
                .email(request.getUsername()+"@email.com")
                .telno("01000000000")
                .pmnCd("PMN0001")
                .useyn("Y")
                .build();

        Userinfo saveUser = loginRepository.save(userinfo);

        return new ApiResponse<>(SC_CREATED, new SignUpResponse(saveUser));
    }

}
