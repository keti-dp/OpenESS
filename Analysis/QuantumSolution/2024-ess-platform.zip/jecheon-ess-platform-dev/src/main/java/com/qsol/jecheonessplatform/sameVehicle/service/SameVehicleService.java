package com.qsol.jecheonessplatform.sameVehicle.service;

import com.qsol.jecheonessplatform.common.entity.CustomerCar;
import com.qsol.jecheonessplatform.common.entity.TestMaster;
import com.qsol.jecheonessplatform.common.entity.code.CodeInfo;
import com.qsol.jecheonessplatform.common.interfaceCommon.CommonInterface;
import com.qsol.jecheonessplatform.common.repository.CodeRepository;
import com.qsol.jecheonessplatform.common.repository.CustomerCarRepository;
import com.qsol.jecheonessplatform.common.repository.TestMasterRepository;
import com.qsol.jecheonessplatform.common.service.CodeService;
import com.qsol.jecheonessplatform.common.util.QsolModelMapper;
import com.qsol.jecheonessplatform.sameVehicle.dto.request.VehicleDataRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Transactional(readOnly = true)
@RequiredArgsConstructor
@Service
public class SameVehicleService {
    private final TestMasterRepository testMasterRepository;
    private final CustomerCarRepository customerCarRepository;
    private final CodeRepository codeRepository;
    private final CodeService codeService;

    public TestMaster svFirstList(String vmlCd, String vehicleNo) { // 동일 차량 데이터 분석 - 리스트 - 상단
        CommonInterface in = testMasterRepository.svFirstList(vehicleNo, vmlCd);
        if(in == null) {
            TestMaster nullList = new TestMaster();
            nullList.setVmlCd(null);
            nullList.setVehicleNo(null);
            nullList.setCarYear(null);
            nullList.setBatteryCap(null);
            nullList.setStartSoc(null);
            nullList.setLastSoc(null);
            nullList.setSoh(null);
            return nullList;
        } else {
            return QsolModelMapper.map(in, TestMaster.class);
        }
    }

    public List<TestMaster> svMainList(String vmlCd, String vehicleNo) { // 동일 차량 데이터 분석 - 리스트 - 메인
        List<CommonInterface> in = testMasterRepository.svMainList(vehicleNo, vmlCd);
        return QsolModelMapper.map(in, TestMaster.class);

    }

    public List<CustomerCar> getVehicleNo(String varCdNm, String vmlCd) {
        CodeInfo ci = codeRepository.findByCodeNmAndUseYn(varCdNm, true);
        return customerCarRepository.findByVarCdAndVmlCd(ci.getCode(), vmlCd);
    }

}
