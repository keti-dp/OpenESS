package com.qsol.jecheonessplatform.login.dto.response;

import com.qsol.jecheonessplatform.common.entity.login.Userinfo;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class SignUpResponse {

    private int userId;
    private String username;
    public SignUpResponse(Userinfo userinfo) {
        this.userId = userinfo.getUserId();
        this.username = userinfo.getUsername();
    }
}
