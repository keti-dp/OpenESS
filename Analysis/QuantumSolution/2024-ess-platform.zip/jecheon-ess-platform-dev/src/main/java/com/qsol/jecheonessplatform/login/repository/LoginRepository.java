package com.qsol.jecheonessplatform.login.repository;

import com.qsol.jecheonessplatform.common.entity.login.Userinfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface LoginRepository extends JpaRepository<Userinfo, String> {
    Optional<Userinfo> findByUsername(String username);
}
