package com.qsol.jecheonessplatform.sameVehicle.dto.reponse;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
@Data
public class SelectBoxResponse {
    private String varSelect;
    private String vmlSelect;
    private String vehicleNo;
}
