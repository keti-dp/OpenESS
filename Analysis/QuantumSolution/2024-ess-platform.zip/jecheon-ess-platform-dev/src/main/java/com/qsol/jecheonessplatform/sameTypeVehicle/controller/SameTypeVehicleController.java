package com.qsol.jecheonessplatform.sameTypeVehicle.controller;

import com.qsol.jecheonessplatform.common.entity.CustomerCar;
import com.qsol.jecheonessplatform.common.entity.TestMaster;
import com.qsol.jecheonessplatform.common.entity.code.CodeInfo;
import com.qsol.jecheonessplatform.common.service.CodeService;
import com.qsol.jecheonessplatform.sameTypeVehicle.dto.SameTypeVehicleSearchFormDto;
import com.qsol.jecheonessplatform.sameTypeVehicle.service.SameTypeVehicleService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequiredArgsConstructor
@Slf4j
public class SameTypeVehicleController {
    private final CodeService codeService;
    private final SameTypeVehicleService sameTypeVehicleService;

    @GetMapping("/views/sameTypeVehicle")
    public String sameTypeVehicleController(Model model, SameTypeVehicleSearchFormDto sameTypeVehicleSearchFormDto) {
        try {
            String vmlCd = sameTypeVehicleSearchFormDto.getVmlCd();
            String carYear = sameTypeVehicleSearchFormDto.getCarYear();
            String customerId = sameTypeVehicleSearchFormDto.getCustomerId();

            boolean flag = false;

            if (vmlCd != null && carYear != null && customerId != null) {
                flag = !( vmlCd.equals("none") || carYear.equals("none") || customerId.equals("none") );
            }

            List<CodeInfo> vehicleTypeList = codeService.getVmlCdList();
            TestMaster testMaster = sameTypeVehicleService.getTestMasterData(sameTypeVehicleSearchFormDto.getCustomerId());

            if (flag) {
                List<TestMaster> testMasterList  = new ArrayList<>();
                if (testMaster != null) {
                    testMasterList  = sameTypeVehicleService.getTestMasterDataList(vmlCd, carYear, customerId, testMaster.getRegistDt());
                    testMasterList = (testMasterList == null) ? new ArrayList<>() : testMasterList;
                }

                model.addAttribute("testMasterList", testMasterList);

                if (carYear != null) {
                    List<CustomerCar> carYearList = sameTypeVehicleService.getCarYearList(sameTypeVehicleSearchFormDto.getVmlCd());
                    model.addAttribute("carYearList", carYearList);
                }

                if (customerId != null) {
                    List<CustomerCar> vehicleNumberList = sameTypeVehicleService.getVehicleNumberList(sameTypeVehicleSearchFormDto.getVmlCd(), sameTypeVehicleSearchFormDto.getCarYear());
                    model.addAttribute("vehicleNumberList", vehicleNumberList);

                    if (testMaster == null) {
                        CustomerCar customerCar = sameTypeVehicleService.getCustomerCar(Integer.valueOf(sameTypeVehicleSearchFormDto.getCustomerId()));
                        model.addAttribute("customerCar", customerCar);
                    }
                }
            }

            model.addAttribute("sameTypeVehicleSearchFormDto", sameTypeVehicleSearchFormDto);
            model.addAttribute("vehicleTypeList", vehicleTypeList);
            model.addAttribute("testMaster", testMaster);



        } catch (Exception e) {
            log.info("Error SameTypeVehicleController sameTypeVehicleController");
            e.printStackTrace();
        }

        return "views/sameTypeVehicle";
    }

    @GetMapping("/views/sameTypeVehicle/getCarYearList/{vmlCd}")
    public ModelAndView getCarYearList(@PathVariable("vmlCd") String vmlCd, ModelAndView mav) {
        try {
            List<CustomerCar> carYearList = sameTypeVehicleService.getCarYearList(vmlCd);
            mav.addObject("carYearList", carYearList);
            mav.setViewName("views/sameTypeVehicle :: #carYearList");
        } catch (Exception e) {
            log.info("Error SameTypeVehicleController getCarYearList");
            e.printStackTrace();
        }
        return mav;
    }

    @GetMapping("/views/sameTypeVehicle/getVehicleNumber/{vmlCd}/{carYear}")
    public ModelAndView getVehicleNumber(@PathVariable("vmlCd") String vmlCd, @PathVariable("carYear") String carYear, ModelAndView mav) {
        try {
            List<CustomerCar> vehicleNumberList = sameTypeVehicleService.getVehicleNumberList(vmlCd, carYear);
            mav.addObject("vehicleNumberList", vehicleNumberList);
            mav.setViewName("views/sameTypeVehicle :: #vehicleNumberList");
        } catch (Exception e) {
            log.info("Error SameTypeVehicleController getVehicleNumber");
            e.printStackTrace();
        }
        return mav;
    }


    @ResponseBody
    @PostMapping(value = "/views/sameTypeVehicle/chart")
    public void responseChartData(HttpServletResponse response, SameTypeVehicleSearchFormDto sameTypeVehicleSearchFormDto) {

        try {
            JSONObject data = sameTypeVehicleService.getResponseSohData(sameTypeVehicleSearchFormDto);
            response.setCharacterEncoding("UTF-8");
            response.setContentType("text/html; charset=UTF-8");
            response.getWriter().print(data);
        } catch (Exception e) {
            log.info("Error SameTypeVehicleController responseChartData");
            e.printStackTrace();
        }
    }
}
