package com.qsol.jecheonessplatform.exception.jwt;

import com.qsol.jecheonessplatform.exception.GlobalException;

public class InvalidTokenException extends GlobalException {

    private static final String MESSAGE = "Invalid token.";

    public InvalidTokenException(Throwable cause) {
        super(MESSAGE, cause);
    }

    @Override
    public int getStatusCode() {
        return 401;
    }
}
