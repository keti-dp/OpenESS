package com.qsol.jecheonessplatform.common.controller;

import com.qsol.jecheonessplatform.common.entity.CustomerCar;
import com.qsol.jecheonessplatform.common.entity.TestMaster;
import com.qsol.jecheonessplatform.common.repository.CustomerCarRepository;
import com.qsol.jecheonessplatform.common.service.CodeService;
import com.qsol.jecheonessplatform.sameVehicle.dto.request.VehicleDataRequest;
import com.qsol.jecheonessplatform.sameVehicle.service.SameVehicleService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequiredArgsConstructor
@Slf4j
public class CommonController {
    private final CustomerCarRepository customerCarRepository;

    @GetMapping(value = "/")
    public String login() {
        try {
        } catch (Exception e) {
            log.info("Error LoginController login");
            e.printStackTrace();
        }
        return "views/login";
    }

    @ResponseBody
    @GetMapping(value = "/findCustomerIdAndCarYear")
    public CustomerCar findCustomerIdAndCarYear(VehicleDataRequest vehicleDataRequest) {
        CustomerCar cc = customerCarRepository.findByVmlCdAndVehicleNo(vehicleDataRequest.getVmlCd(), vehicleDataRequest.getVehicleNo());
        return cc;
    }

}
