package com.qsol.jecheonessplatform.sameVehicle.controller;

import com.qsol.jecheonessplatform.common.entity.CustomerCar;
import com.qsol.jecheonessplatform.common.entity.code.CodeInfo;
import com.qsol.jecheonessplatform.common.service.CodeService;
import com.qsol.jecheonessplatform.sameVehicle.dto.request.VehicleDataRequest;
import com.qsol.jecheonessplatform.sameVehicle.service.SameVehicleService;
import com.qsol.jecheonessplatform.common.entity.TestMaster;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.math.BigDecimal;
import java.util.List;

@RequiredArgsConstructor
@Controller
public class SameVehicleController {
    private final SameVehicleService sameVehicleService;
    private final CodeService codeService;

    @GetMapping("/views/sameVehicle")
    public String sameVehicleView(Model model) {
        codeService.findByCodeGpAndUseYn("VAR", true, model);
        return "views/sameVehicle";
    }

    @GetMapping(value = "/sameVehicleList/{varCdNm}/{vmlCd}/{vehicleNo}") // 충전 횟수 리스트에서 클릭하여 넘어올 때
    public String sameVehicleClickList(@PathVariable("varCdNm") String varCdNm, @PathVariable("vmlCd") String vmlCd, @PathVariable("vehicleNo") String vehicleNo, Model model) {
        try {
            codeService.findByCodeGpAndUseYn("VAR", true, model);
            if(!vmlCd.equals("none")) {
                codeService.sameVehicleSelectBoxControl(vmlCd, vehicleNo, model);
                TestMaster firstList = sameVehicleService.svFirstList(vmlCd, vehicleNo);
                List<TestMaster> mainList = sameVehicleService.svMainList(vmlCd, vehicleNo);

                CodeInfo ci = codeService.findByCodeAndUseYn(vmlCd, true);
                firstList.setVmlView(ci.getCodeNm());

                if (mainList.size() == 0) {
                    TestMaster tm = new TestMaster();
                    tm.setViewCheck("none");
                    mainList.add(0, tm);
                }
                model.addAttribute("svFirstList", firstList);
                model.addAttribute("svMainList", mainList);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "views/sameVehicle";
    }

    @GetMapping(value = "/sameVehicleFirstList") // 조회 버튼 클릭 시
    public ModelAndView sameVehicleFirstList(VehicleDataRequest vehicleDataRequest, ModelAndView mav, Model model) {
        try {
            CodeInfo ci = codeService.findByCodeAndUseYn(vehicleDataRequest.getVmlCd(), true);
            TestMaster svFirstList = sameVehicleService.svFirstList(vehicleDataRequest.getVmlCd(), vehicleDataRequest.getVehicleNo());
            if (svFirstList.getVmlCd() != null) {
                svFirstList.setVmlView(ci.getCodeNm());
            }

            mav.addObject("svFirstList", svFirstList);
            mav.setViewName("views/sameVehicle :: #svFirstList");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mav;
    }

    @GetMapping(value = "/sameVehicleMainList") // 조회 버튼 클릭 시
    public ModelAndView sameVehicleMainList(VehicleDataRequest vehicleDataRequest, ModelAndView mav) {
        try {
            List<TestMaster> svMainList = sameVehicleService.svMainList(vehicleDataRequest.getVmlCd(), vehicleDataRequest.getVehicleNo());

            if (svMainList.size() == 0) {
                TestMaster tm = new TestMaster();
                tm.setViewCheck("none");
                svMainList.add(0, tm);
            }
            mav.addObject("svMainList", svMainList);
            mav.setViewName("views/sameVehicle :: #svMainList");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mav;
    }

    @GetMapping("/getVmlCode/{varCdNm}")
    public ModelAndView getVmlCode(@PathVariable("varCdNm") String varCdNm, ModelAndView mav) {
        try {
            List<CodeInfo> vmlCodeList = codeService.findByCodeGpAndReferenceAndUseYn("VML", varCdNm, true);

            mav.addObject("vmlCodeList", vmlCodeList);
            mav.setViewName("views/sameVehicle :: #vmlCodeList");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mav;
    }

    @GetMapping("/getVehicleNo/{varCdNm}/{vmlCd}")
    public ModelAndView getVehicleNo(@PathVariable("varCdNm") String varCdNm, @PathVariable("vmlCd") String vmlCd, ModelAndView mav) {
        try {
            List<CustomerCar> vehicleNoList = sameVehicleService.getVehicleNo(varCdNm, vmlCd);

            mav.addObject("vehicleNoList", vehicleNoList);
            mav.setViewName("views/sameVehicle :: #vehicleNoList");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mav;
    }
}