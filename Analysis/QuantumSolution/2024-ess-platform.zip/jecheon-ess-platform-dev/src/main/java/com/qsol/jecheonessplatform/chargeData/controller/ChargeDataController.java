package com.qsol.jecheonessplatform.chargeData.controller;

import com.qsol.jecheonessplatform.chargeData.dto.TestMasterSearchFormDto;
import com.qsol.jecheonessplatform.chargeData.service.ChargeDataService;
import com.qsol.jecheonessplatform.common.entity.TestMaster;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.Optional;

@Controller
@RequiredArgsConstructor
@Slf4j
public class ChargeDataController {

    private final ChargeDataService chargeDataService;
    @GetMapping(value = {"/views/main", "/views/main/{page}"})
    public String mainController(Model model, @PathVariable("page") Optional<Integer> page, TestMasterSearchFormDto testMasterSearchFormDto) {
        try {
            Pageable pageable = PageRequest.of(page.isPresent() ? page.get() : 0, 12);
            Page<TestMaster> testMasters = chargeDataService.getTestMasterList(pageable, testMasterSearchFormDto);

            model.addAttribute("testMasterSearchFormDto", testMasterSearchFormDto);
            model.addAttribute("testMasters", testMasters);
            model.addAttribute("maxPage", 10);
        } catch (Exception e) {
            log.info("Error MainController mainController");
            e.printStackTrace();
        }
        return "views/main";
    }


}
