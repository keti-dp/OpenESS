package com.qsol.jecheonessplatform.common.dto.request;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class SearchRequest {

    private int countPerPage; // 한 페이지에 나타낼 수
    private int pageNo; // 선택된 페이지 번호 (Service에서 처리 시, pageNo - 1)
}
