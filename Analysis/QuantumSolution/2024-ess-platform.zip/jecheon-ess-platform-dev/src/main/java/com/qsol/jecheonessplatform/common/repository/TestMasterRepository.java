package com.qsol.jecheonessplatform.common.repository;

import com.qsol.jecheonessplatform.common.interfaceCommon.CommonInterface;
import com.qsol.jecheonessplatform.common.entity.TestMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository
public interface TestMasterRepository extends JpaRepository<TestMaster, String> {

    /* 전체 데이터 조회 */
    @Query(value = "select " +
            "tm.TEST_ID as 'testId', " +
            "ci.CODENM AS 'vmlCd', " +
            "cc.VEHICLE_NO AS 'vehicleNo', " +
            "cc.car_year AS 'carYear', " +
            "cc.battery_capacity AS 'batteryCap', " +
            "tm.START_SOC AS 'startSoc', " +
            "tm.LAST_SOC AS 'lastSoc'," +
            "tm.SOH AS 'SOH', " +
            "tm.REGIST_DT AS 'registDt' " +
            "from tb_test_master tm " +
            "INNER JOIN tb_customer_car cc On tm.CUSTOMER_ID = cc.CUSTOMER_ID " +
            "INNER JOIN tb_codeinfo ci On cc.VML_CD = ci.CODE " +
            "WHERE tm.TEST_ID = :testId "
            , nativeQuery = true)
    CommonInterface findTopByTestId(@Param("testId") Integer testId);

    @Query(value = "select " +
            "tm.TEST_ID as 'testId', " +
            "ci.CODENM AS 'vmlCd', " +
            "cc.BATTERY_CAPACITY AS 'batteryCap', " +
            "cc.VEHICLE_NO AS 'vehicleNo', " +
            "cc.car_year AS 'carYear', " +
            "tm.LOC_ID AS 'locId', " +
            "tm.START_DT AS 'startDt', " +
            "tm.END_DT AS 'endDt', " +
            "tm.START_SOC AS 'startSoc', " +
            "tm.LAST_SOC AS 'lastSoc'," +
            "tm.SOH AS 'SOH', " +
            "tm.REGIST_DT AS 'registDt' " +
            "from tb_test_master tm " +
            "INNER JOIN tb_customer_car cc On tm.CUSTOMER_ID = cc.CUSTOMER_ID " +
            "INNER JOIN tb_codeinfo ci On cc.VML_CD = ci.CODE " +
            "WHERE (:vehicleNumber IS NULL OR cc.VEHICLE_NO =:vehicleNumber) " +
            "ORDER BY " +
            "   CASE " +
            "       WHEN :sortData = 'vmlCd' THEN cc.VML_CD " +
            "       WHEN :sortData = 'locId' THEN tm.LOC_ID " +
            "       WHEN :sortData = 'startDt' THEN tm.START_DT " +
            "       WHEN :sortData = 'endDt' THEN tm.END_DT " +
            "       WHEN :sortData = 'soh' THEN tm.SOH " +
            "   END ASC, tm.REGIST_DT ASC", nativeQuery = true)
    List<CommonInterface> getTestMasterListAsc(@Param("vehicleNumber") String vehicleNumber, @Param("sortData") String sortData);

    @Query(value = "select " +
            "tm.TEST_ID as 'testId', " +
            "ci.CODENM AS 'vmlCd', " +
            "cc.BATTERY_CAPACITY AS 'batteryCap', " +
            "cc.VEHICLE_NO AS 'vehicleNo', " +
            "cc.car_year AS 'carYear', " +
            "tm.LOC_ID AS 'locId', " +
            "tm.START_DT AS 'startDt', " +
            "tm.END_DT AS 'endDt', " +
            "tm.START_SOC AS 'startSoc', " +
            "tm.LAST_SOC AS 'lastSoc'," +
            "tm.SOH AS 'SOH', " +
            "tm.REGIST_DT AS 'registDt' " +
            "from tb_test_master tm " +
            "INNER JOIN tb_customer_car cc On tm.CUSTOMER_ID = cc.CUSTOMER_ID " +
            "INNER JOIN tb_codeinfo ci On cc.VML_CD = ci.CODE " +
            "WHERE (:vehicleNumber IS NULL OR cc.VEHICLE_NO =:vehicleNumber) " +
            "ORDER BY " +
            "   CASE " +
            "       WHEN :sortData = 'vmlCd' THEN cc.VML_CD " +
            "       WHEN :sortData = 'locId' THEN tm.LOC_ID " +
            "       WHEN :sortData = 'startDt' THEN tm.START_DT " +
            "       WHEN :sortData = 'endDt' THEN tm.END_DT " +
            "       WHEN :sortData = 'soh' THEN tm.SOH " +
            "   END DESC, tm.REGIST_DT DESC", nativeQuery = true)
    List<CommonInterface> getTestMasterListDesc(@Param("vehicleNumber") String vehicleNumber, @Param("sortData") String sortData);


    /* 동종 차량/연식 비교 페이지 */
    /* 리스트 화면 */
    @Query(value = "SELECT " +
            "cc.VML_CD AS vmlCd, " +
            "cc.vehicle_no AS vehicleNo, " +
            "cc.car_year AS carYear, " +
            "cc.battery_capacity AS batteryCap, " +
            "tm.start_soc AS startSoc, " +
            "tm.LAST_SOC AS lastSoc, " +
            "tm.SOH as soh, " +
            "tm.REGIST_DT as registDt " +
            "FROM tb_test_master tm " +
            "INNER JOIN tb_customer_car cc ON tm.CUSTOMER_ID = cc.CUSTOMER_ID " +
            "WHERE tm.CUSTOMER_ID = :customerId AND tm.LAST_SOC IS NOT NULL AND tm.SOH IS NOT NULL " +
//            "AND tm.START_SOC IS NOT NULL " +
            "ORDER BY tm.REGIST_DT DESC LIMIT 1", nativeQuery = true)
    CommonInterface findTopByCustomerIdOrderByRegistDtDesc(@Param("customerId") String customerId);

    @Query(value = "SELECT " +
            "cc.VML_CD AS vmlCd, " +
            "cc.vehicle_no AS vehicleNo, " +
            "cc.car_year AS carYear, " +
            "cc.battery_capacity AS batteryCap, " +
            "tm.start_soc AS startSoc, " +
            "tm.LAST_SOC AS lastSoc, " +
            "tm.SOH as soh, " +
            "tm.REGIST_DT as registDt " +
            "FROM tb_test_master tm " +
            "INNER JOIN tb_customer_car cc ON tm.CUSTOMER_ID = cc.CUSTOMER_ID " +
            "WHERE tm.CUSTOMER_ID = :customerId AND tm.LAST_SOC IS NOT NULL AND tm.SOH IS NOT NULL " +
//            "AND tm.START_SOC IS NOT NULL " +
            "ORDER BY tm.REGIST_DT Asc LIMIT 1", nativeQuery = true)
    CommonInterface findTopByCustomerIdOrderByRegistDtAsc(@Param("customerId") String customerId);

    @Query(value = "" +
            "SELECT " +
            "cc.VML_CD AS vmlCd, " +
            "cc.vehicle_no AS vehicleNo, " +
            "cc.car_year AS carYear, " +
            "cc.battery_capacity AS batteryCap, " +
            "tm.start_soc AS startSoc, " +
            "tm.LAST_SOC AS lastSoc, " +
            "tm.SOH as soh, " +
            "tm.REGIST_DT as registDt, " +
            "COUNT(*) as count " +
            "FROM tb_test_master tm INNER JOIN tb_customer_car cc ON tm.CUSTOMER_ID = cc.CUSTOMER_ID " +
            "WHERE " +
            "cc.VML_CD = :vmlCd " +
            "AND cc.CAR_YEAR = :carYear " +
            "AND NOT tm.CUSTOMER_ID = :customerId " +
            "AND tm.LAST_SOC IS NOT NULL AND tm.SOH IS NOT NULL " +
            "AND tm.REGIST_DT >= :registDt " +
//            "AND tm.START_SOC IS NOT NULL " +
            "GROUP BY tm.CUSTOMER_ID " +
            "ORDER BY tm.REGIST_DT DESC", nativeQuery = true)
    List<CommonInterface> findByVmlCdAndCarYearAndNotCustomerIdAndRegistDtAfterOrderByRegistDtDesc(
            @Param("vmlCd") String vmlCd,
            @Param("carYear") String carYear,
            @Param("customerId") String customerId,
            @Param("registDt") Timestamp registDt
    );



    /* Chart 화면 */

/*
    @Query(value = "SELECT " +
            "tm.SOH as soh, " +
            "tm.REGIST_DT as registDt " +
            "FROM tb_test_master tm " +
            "INNER JOIN tb_customer_car cc ON tm.CUSTOMER_ID = cc.CUSTOMER_ID " +
            "WHERE tm.CUSTOMER_ID = :customerId AND tm.LAST_SOC IS NOT NULL AND tm.SOH IS NOT NULL " +
//            "AND tm.START_SOC IS NOT NULL " +
            "ORDER BY tm.REGIST_DT ASC", nativeQuery = true)
    List<CommonInterface> findByCustomerId(@Param("customerId") String customerId);
*/

    @Query(value = "SELECT " +
            "tm.CUSTOMER_ID as customerId, " +
            "tm.SOH as soh, " +
            "tm.REGIST_DT as registDt " +
            "FROM tb_test_master tm " +
            "INNER JOIN tb_customer_car cc ON tm.CUSTOMER_ID = cc.CUSTOMER_ID " +
            "WHERE cc.VML_CD = :vmlCd " +
            "AND cc.CAR_YEAR = :carYear " +
            "AND tm.LAST_SOC IS NOT NULL AND tm.SOH IS NOT NULL " +
            "AND tm.REGIST_DT >= :startDt " +
//            "AND tm.START_SOC IS NOT NULL " +
            "ORDER BY tm.REGIST_DT ASC", nativeQuery = true)
    List<CommonInterface> findByVmlCdAndCarYearOrderByRegistDtAsc(
            @Param("vmlCd") String vmlCd,
            @Param("carYear") String carYear,
            @Param("startDt") Timestamp startDt
    );


/*
    @Query(value = "SELECT " +
            "tm.SOH as soh, " +
            "tm.REGIST_DT as registDt " +
            "FROM tb_test_master tm " +
            "INNER JOIN tb_customer_car cc ON tm.CUSTOMER_ID = cc.CUSTOMER_ID " +
            "WHERE tm.CUSTOMER_ID != :customerId AND tm.LAST_SOC IS NOT NULL AND tm.SOH IS NOT NULL " +
//            "AND tm.START_SOC IS NOT NULL " +
            "ORDER BY tm.REGIST_DT ASC", nativeQuery = true)
    List<CommonInterface> findByNotCustomerId(@Param("customerId") String customerId);
*/



    //  --- 충전 횟수별 데이터
    @Query(value = "SELECT ci.codeNm as vmlView, tc.vehicle_no as vehicleNo, tc.var_cd as varCd, tc.vml_cd as vmlCd, tc.car_year as carYear, count(*) as COUNT, tm.*, MIN(tm.regist_dt) as minRegistDt, max(tm.regist_dt) as maxRegistDt, cc.battery_capacity AS batteryCap\n" +
            "from tb_test_master tm inner join tb_test_car tc\n" +
            "on tm.test_id = tc.test_id AND tm.success_yn = '1' AND tm.soh IS NOT NULL AND tm.EVCCID IS NOT NULL, tb_codeinfo ci, tb_customer_car cc\n" +
            "where tc.VML_CD = ci.code AND tm.customer_id = cc.customer_id\n" +
            "group by tc.VEHICLE_NO\n" +
            "order by 6 DESC", nativeQuery = true)
    List<CommonInterface> chargeCountList();

    //  --- 충전 데이터 조회
    @Query(value = "SELECT tc.vehicle_no AS vehicleNo, tc.var_cd AS varCd, tc.vml_cd AS vmlCd, tc.car_year AS carYear, tm.start_soc as startSoc, tm.last_soc as lastSoc, tm.soh as soh, 0 as count, cc.battery_capacity as batteryCap \n" +
            "FROM tb_test_master tm INNER JOIN tb_test_car tc " +
            "on tc.vehicle_no = :vehicleNo AND tc.vml_cd = :vmlCd and tm.test_id = tc.test_id AND tm.success_yn = 1 AND tm.soh IS NOT NULL, tb_customer_car cc " +
            "where tm.customer_id = cc.customer_id " +
            "ORDER BY tm.regist_dt DESC LIMIT 1", nativeQuery = true)
    CommonInterface svFirstList(@Param("vehicleNo") String vehicleNo, @Param("vmlCd") String vmlCd); // 상단 리스트 // @Param("varCd") String varCd, // AND tc.var_cd = :varCd

    @Query(value = "SELECT tm.customer_id as customerId, tm.regist_dt AS registDt, tm.soh AS soh, (SELECT COUNT(regist_dt)+1 FROM tb_test_master WHERE customer_id = customerId and regist_dt < registDt) AS count\n" +
            "FROM tb_test_master tm INNER JOIN tb_test_car tc " +
            "ON tc.vehicle_no = :vehicleNo AND tc.vml_cd = :vmlCd and tm.test_id = tc.test_id AND tm.success_yn = 1 AND tm.soh IS NOT NULL " +
            "ORDER BY tm.regist_dt ASC", nativeQuery = true)
    List<CommonInterface> svMainList(@Param("vehicleNo") String vehicleNo, @Param("vmlCd") String vmlCd); // 메인 리스트 // @Param("varCd") String varCd, // AND tc.var_cd = :varCd

    @Query(value = "SELECT regist_dt as registDt, soh, customer_id as customerId " +
            " FROM tb_test_master WHERE evccid = :evccid AND soh IS NOT NULL ORDER BY regist_dt ASC", nativeQuery = true)
    List<CommonInterface> getSvChart(@Param("evccid") String evccid);
}

