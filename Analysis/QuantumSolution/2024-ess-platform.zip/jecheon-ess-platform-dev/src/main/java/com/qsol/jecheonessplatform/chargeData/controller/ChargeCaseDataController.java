package com.qsol.jecheonessplatform.chargeData.controller;

import com.qsol.jecheonessplatform.chargeData.entity.TestData;
import com.qsol.jecheonessplatform.chargeData.service.ChargeDataService;
import com.qsol.jecheonessplatform.common.entity.TestMaster;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Optional;

@Controller
@RequiredArgsConstructor
@Slf4j
public class ChargeCaseDataController {

    private final ChargeDataService chargeDataService;

    @GetMapping(value = {"/views/chargeCase", "/views/chargeCase/{page}"})
    public String chargeCaseController(Model model, @PathVariable("page") Optional<Integer> page, @RequestParam(value="testId", required = false) Integer testId) {
        try {
            Pageable pageable = PageRequest.of(page.isPresent() ? page.get() : 0, 12);
            Page<TestData> testDatas = null;
            TestMaster testMaster = null;

            if (testId != null) {
                testDatas = chargeDataService.getChargeCaseDataList(pageable, Long.valueOf(testId));
                testMaster = chargeDataService.getTestMasterData(testId);
            }

            model.addAttribute("testDatas", testDatas);
            model.addAttribute("testMaster", testMaster);
            model.addAttribute("maxPage", 10);
        } catch (Exception e) {
            log.info("Error ChargeCaseDataController chargeCaseController");
            e.printStackTrace();
        }

        return "views/chargeCase";
    }


}
