package com.qsol.jecheonessplatform.chargeData.repository;

import com.qsol.jecheonessplatform.chargeData.entity.TestData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TestDataRepository extends JpaRepository<TestData, String> {
    List<TestData> findByTestIdOrderByRegistDtAsc(Long testId);
}

