package com.qsol.jecheonessplatform.sameTypeVehicle.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter
@ToString
public class SameTypeVehicleSearchFormDto {

    private String vmlCd;
    private String carYear;
    private String customerId;


    private String searchQuery = "";

    private String testVmlCd;
    private String testVehicleNo;

}
