package com.qsol.jecheonessplatform.common.service;

import com.qsol.jecheonessplatform.common.entity.CustomerCar;
import com.qsol.jecheonessplatform.common.entity.TestMaster;
import com.qsol.jecheonessplatform.common.repository.CodeRepository;
import com.qsol.jecheonessplatform.common.entity.code.CodeInfo;
import com.qsol.jecheonessplatform.common.repository.CustomerCarRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;

import java.util.List;

@Slf4j
@Transactional(readOnly = true)
@RequiredArgsConstructor
@Service
public class CodeService {
    private final CodeRepository codeRepository;
    private final CustomerCarRepository customerCarRepository;

    public void findByCodeGpAndUseYn(String codeGp, Boolean useYn, Model model) {
        try {
            List<CodeInfo> varCodeList = codeRepository.findByCodeGpAndUseYn(codeGp, useYn);
            TestMaster svFirstList = new TestMaster();
            svFirstList.setVmlView(null);
            svFirstList.setVehicleNo(null);
            svFirstList.setCarYear(null);
            svFirstList.setBatteryCap(null);
            svFirstList.setStartSoc(null);
            svFirstList.setLastSoc(null);
            svFirstList.setSoh(null);
            model.addAttribute("varCodeList", varCodeList);
            model.addAttribute("svFirstList", svFirstList);
        } catch (Exception e) {
            log.info("Error CodeService findByCodeGpAndUseYn");
            e.printStackTrace();
        }
    }

    public void sameVehicleSelectBoxControl(String vmlCd, String vehicleNo, Model model) {
        CodeInfo getReference = codeRepository.findByCodeAndUseYn(vmlCd, true);
        List<CodeInfo> vmlCodeList = codeRepository.findByCodeGpAndReferenceAndUseYn("VML", getReference.getReference(), true);
        CustomerCar getCarCode = customerCarRepository.findByVehicleNo(vehicleNo);
        List<CustomerCar> vehicleNoList = customerCarRepository.findByVarCdAndVmlCd(getCarCode.getVarCd(), getCarCode.getVmlCd());

        model.addAttribute("vmlCodeList", vmlCodeList);
        model.addAttribute("vehicleNoList", vehicleNoList);
    }

    public CodeInfo findByCodeAndUseYn(String code, boolean useYn) {
        return codeRepository.findByCodeAndUseYn(code, useYn);
    }

    public List<CodeInfo> getVmlCdList() {
        return codeRepository.findByCodeGpAndUseYn("VML",true);
    }

    public String getVarCodeNm(String vmlCd) {
        CodeInfo codeInfo = findByCodeAndUseYn(vmlCd, true);
        codeInfo = codeRepository.findByCodeNmAndUseYn(codeInfo.getReference(), true);
        return codeInfo.getCodeNm();
    }

    public List<CodeInfo> findByCodeGpAndReferenceAndUseYn(String vml, String varCdNm, boolean useYn) {
        return codeRepository.findByCodeGpAndReferenceAndUseYn(vml, varCdNm, useYn);
    }
}
