package com.qsol.jecheonessplatform.exception.jwt;

import com.qsol.jecheonessplatform.exception.GlobalException;

public class ExpirationException extends GlobalException {

    private static final String MESSAGE = "Token Expiration.";

    public ExpirationException(Throwable cause) {
        super(MESSAGE, cause);
    }

    @Override
    public int getStatusCode() {
        return 401;
    }
}
