package com.qsol.jecheonessplatform.common.entity;

import com.qsol.jecheonessplatform.sameVehicle.dto.reponse.VehicleDataResponse;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Getter
@Setter
@Entity
@Table(name = "tb_test_master")
public class TestMaster extends VehicleDataResponse {

    @Column(name = "TEST_ID")
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int testId;

    @Column(name = "REQ_ID", nullable = false)
    private int reqId;

    @Column(name = "LOC_ID")
    private int locId;

    @Column(name = "CUSTOMER_ID", nullable = false)
    private String customerId;

    @Column(name = "EVCCID", nullable = false)
    private String evccid;

    @Column(name = "START_DT", nullable = false)
    private Timestamp startDt;

    @Column(name = "END_DT", nullable = false)
    private Timestamp endDt;

    @Column(name = "START_SOC", nullable = false)
    private BigDecimal startSoc;

    @Column(name = "LAST_SOC", nullable = false)
    private BigDecimal lastSoc;

    @Column(name = "SOH", nullable = false)
    private BigDecimal soh;

    @Column(name = "SUCCESS_YN", nullable = false)
    private int successYn;

    @Column(name = "RESULT_MSG", nullable = false)
    private String resultMsg;

    @Column(name = "MANAGER_ID", nullable = false)
    private String managerId;

    @Column(name = "REGIST_DT", nullable = false)
    private Timestamp registDt;

}
