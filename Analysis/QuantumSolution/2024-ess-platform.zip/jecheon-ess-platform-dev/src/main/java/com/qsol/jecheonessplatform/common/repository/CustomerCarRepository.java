package com.qsol.jecheonessplatform.common.repository;

import com.qsol.jecheonessplatform.common.entity.CustomerCar;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CustomerCarRepository extends JpaRepository<CustomerCar, String> {

    CustomerCar findByCustomerId(Integer customerId);

    CustomerCar findByVmlCdAndVehicleNo(String vmlCd, String vehicleNo);

    @Query(value="SELECT * FROM tb_customer_car WHERE VML_CD = :vmlCd GROUP BY CAR_YEAR", nativeQuery = true)
    List<CustomerCar> findByVmlCd(@Param("vmlCd") String vmlCd);

    List<CustomerCar> findByVmlCdAndCarYear(String vmlCd, String carYear);


    List<CustomerCar> findByVmlCdAndEvccidIsNotNull(String vmlCd);

    List<CustomerCar> findByVarCdAndVmlCd(String varCd, String vmlCd);

    CustomerCar findByVehicleNo(String vehicleNo);
}

