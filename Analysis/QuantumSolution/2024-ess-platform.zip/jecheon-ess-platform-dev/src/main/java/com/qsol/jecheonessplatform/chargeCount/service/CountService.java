package com.qsol.jecheonessplatform.chargeCount.service;

import com.qsol.jecheonessplatform.common.entity.TestMaster;
import com.qsol.jecheonessplatform.common.repository.TestMasterRepository;
import com.qsol.jecheonessplatform.common.util.QsolModelMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Transactional(readOnly = true)
@RequiredArgsConstructor
@Service
public class CountService {
    private final TestMasterRepository testMasterRepository;

    public Page<TestMaster> chargeCount(Pageable pageable) { // 충전 횟수별 데이터
        List<TestMaster> tm = QsolModelMapper.map(testMasterRepository.chargeCountList(), TestMaster.class);
        long total = tm.size();
        int start = (int) pageable.getOffset();
        int end = (start + pageable.getPageSize()) > tm.size() ? tm.size() : (start + pageable.getPageSize());
        return new PageImpl<>(tm.subList(start, end), pageable, total);
    }

}
