package com.qsol.jecheonessplatform.sameVehicle.dto.request;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class VehicleDataRequest {
//    private String varCd; // 셀렉박스 차량 제조사
    private String vmlCd; // 셀렉박스 차량 모델
    private String vehicleNo; // input 차량 번호
}
