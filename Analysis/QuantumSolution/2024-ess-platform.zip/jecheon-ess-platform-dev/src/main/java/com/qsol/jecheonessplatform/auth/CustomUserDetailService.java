package com.qsol.jecheonessplatform.auth;

import com.qsol.jecheonessplatform.exception.login.UserNotFoundException;
import com.qsol.jecheonessplatform.common.entity.login.Userinfo;
import com.qsol.jecheonessplatform.login.repository.LoginRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;

@RequiredArgsConstructor
@Service
public class CustomUserDetailService implements UserDetailsService {

    private final LoginRepository loginRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Userinfo userinfo = loginRepository.findByUsername(username).orElseThrow(UserNotFoundException::new);

        Collection<SimpleGrantedAuthority> authorities = new ArrayList<>();
        return new org.springframework.security.core.userdetails.User(userinfo.getUsername(), userinfo.getPassword(), authorities);
    }
}
