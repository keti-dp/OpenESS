$(document).ready(function () {
});

let noneGraphPopup = false;

// ┌─────────────────────────── Graph ───────────────────────────┐
function getSvChart(vmlCd, vehicleNo, name) {
    noneGraphPopup = false;
    $.ajax({
        url: "/views/getSvChart/" + name,
        type: "POST",
        data: {vmlCd, vehicleNo},
        async: true,
        cache: false,
        success: function(data) {
            if (data != null) {
                data = JSON.parse(data);
                if (data.listSize != 0) {
                    if(name == "health") {
                        healthChart(data, vmlCd, vehicleNo);
                    } else {
                        btPredChart(data, vehicleNo);
                    }
                } else {
                    noneGraphPopup = true;
                }
                $(".sv_chart_content").show();
            }
        },
        error: function(result, status, error) {
            console.error("Error ", error);
        }
    });
}

function healthChart(data, vmlCd, vehicleNo) {
    let size = data.nonLinearPoint.length;
    let lastSoh = data.nonLinearPoint[size-1];
    // 차트 옵션 설정
    let healthChartOptions = {
        chart: {
            renderTo: 'healthChart',
            height: 290, //$("#healthChart").height(),
            zoomType: "xy"
        },
        title: {text: data.carModel + ' / ' + vehicleNo + ' - 건강도 추이 분석'},
        xAxis: [{
            categories: data.indexList,
            // tickInterval: 50,
            labels: {enabled: true},
            crosshair: true
        }],
        yAxis: [{
            title: {
                text: 'SoH[%]',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            labels: {
                format: '{value:,.0f}',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            max:100,
            // min: 86,
            min:lastSoh-2,
            opposite: false
        }],
        series: [{
            name: "SoH",
            type: 'scatter',
            data: data.nonLinearPoint,
            marker: {enabled: true},
            color: 'rgb(30, 65, 116)'
        }, {
            name: "배터리 건강도 추이",
            type: 'spline',
            data: data.nonLinearLine,
            marker: {enabled: false},
            color: 'rgb(221, 169, 75)'
        }],
        credits: {enabled: false},
        legend: {enabled: true}
    };

    healthChartOptions = setChartTooltipOptions(healthChartOptions, "health");

    // Highcharts 옵션 설정
    Highcharts.setOptions({
        lang: {
            thousandsSep: ','
        }
    });

    // 차트 그리기
    chart = new Highcharts.chart('healthChart', healthChartOptions);
    getSvChart(vmlCd, vehicleNo, "btPred");
}

function btPredChart(data, vehicleNo) {
    let first = data.sohChartLine[0][1]; // 라인 첫 soh
    let soh = data.sohChartLine[data.sohChartLine.length-1][1]; // 라인 마지막 soh
    let value;
    if(data.sohChartPoint.length != 1) {
        let minusValue = first - soh; // 데이터 처음부터 마지막까지의 총 감소값
        value = minusValue / (data.sohChartLine.length-1); // 하루당 감소되는 값
        soh = data.sohChartLine[data.sohChartLine.length-1][1]; // 데이터 마지막 soh값
    } else {
        value = 0.03;
        soh = data.sohChartPoint[0];
    }


    let indexList = 0;
    let indexListMessage = "";

    // 데이터 평균 감소값으로 예측 계산하여 soh가 80이 될때까지 라인 데이터를 추가, 그 후 남은 예상 수명을 메세지에 표시
    while(true) {
        if(soh < 80 || soh >= 100) {
            indexList = data.indexList.length-1;
            let year = indexList / 365;
            if(year.toFixed(0) >= 1) {
                indexListMessage = "해당 배터리의 예상 수명은 약 " + year.toFixed(0) + "년 이상입니다.";
            } else {
                indexListMessage = "해당 배터리의 예상 수명은 약 1년 이하입니다.";
            }
            break;
        } else {
            soh -= value;
            if(data.sohChartLine[data.sohChartLine.length-1][1] != 0) { // 0값 제거
                data.sohChartLine[data.sohChartLine.length] = [];
            }
            data.sohChartLine[data.sohChartLine.length-1][0] = data.sohChartLine.length-1;
            data.sohChartLine[data.sohChartLine.length-1][1] = soh;
            data.indexList[data.indexList.length] = data.indexList.length;
        }
    }

    // 차트 옵션 설정
    let btPredChartOptions = {
        chart: {
            renderTo: 'btPredChart',
            height: 290, // $("#btPredChart").height(),
            zoomType: "xy"
        },
        title: {text: data.carModel + ' / ' + vehicleNo + ' - RUL 예측'},
        subtitle: {
            text: '',
            style: {fontSize: '14px'},
            align: 'right'
        },
        xAxis: [{
            categories: indexList,
            tickInterval: 50,
            labels: {enabled: true},
            crosshair: true
        }],
        yAxis: [{
            title: {
                text: 'SoH[%]',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            labels: {
                format: '{value:,.0f}',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            max:100,
            min: (data.yMin-10),
            opposite: false
        }],
        series: [{
            name: "SoH",
            type: 'scatter',
            data: data.sohChartPoint,
            marker: {enabled: true},
            color: 'rgb(30, 65, 116)'
        }, {
            name: "배터리 잔여 수명 예측",
            type: 'line',
            data: data.sohChartLine,
            marker: {enabled: false},
            color: 'rgb(221, 169, 75)'
        }, {
            name: '최근',
            type: 'line',
            dashStyle: 'longdash',
            data: data.yBar,
            marker: {enabled: false},
            color: '#ff0000'
        }],
        credits: {enabled: false},
        legend: {enabled: true}
    };

    btPredChartOptions.subtitle.text = indexListMessage;

    btPredChartOptions = setChartTooltipOptions(btPredChartOptions, "btPred");

    // Highcharts 옵션 설정
    Highcharts.setOptions({
        lang: {
            thousandsSep: ','
        }
    });

    // 차트 그리기
    chart = new Highcharts.chart('btPredChart', btPredChartOptions);
}

function setChartTooltipOptions(chartOptions) {
    let tooltipOption = Highcharts.getOptions().tooltip;

    chartOptions.tooltip = {
        headerFormat: tooltipOption.headerFormat.replace('{point.key}', '{point.key}일 차'),
        pointFormat: tooltipOption.pointFormat.replace('{point.y}', '{point.y:.1f}'),
        footerFormat: tooltipOption.footerFormat,
        shared: false,
        style: {
            fontWeight: 'bold',
            fontSize: '14px'
        }
    };

    return chartOptions;
}
