let varCd = "none";
let vmlCd = "none";
let vehicleNo = "none";

$(document).ready(function () {
    $(".gnb .same_vehicle").parent().addClass("active");
    $(".sv_etc_button").attr("disabled", true).addClass("disabled_button");

    let itemResult = urlControl(window.location.href);

    // ┌─────────────────────────── 충전 횟수 페이지에서 온 경우 데이터를 저장
    varCd = itemResult[4];
    vmlCd = itemResult[5];
    vehicleNo = itemResult[6];
    // ┌─────────────────────────── none으로 초기화
    if(varCd == null || varCd == undefined) {
        varCd = 'none';
    }
    if(vmlCd == null || vmlCd == undefined) {
        vmlCd = 'none';
    }
    if(vehicleNo == null || vehicleNo == undefined) {
        vehicleNo = 'none';
    }

    if(varCd == 'none') { // left_menu 직접 클릭으로 접근
        $("#listViewOn").show();
        $("#graphViewOn").hide();
        $("#contentChange").text("그래프로 보기");
        $("#contentChange").val("list");

        setTimeout(function () {
            $(".search_wrap select[name='varCode']").val(varCd).attr("selected", true);
            $(".search_wrap select[name='vmlCode']").val(vmlCd).attr("selected", true);
            $(".search_wrap select[name='vehicleName']").val(vehicleNo).attr("selected", true);
        },0);
    } else { // 이외의 절차로 접근
        $("#listViewOn").show();
        $("#graphViewOn").hide();
        $("#contentChange").text("그래프로 보기");
        $("#contentChange").val("list");

        getSvChart(vmlCd, vehicleNo, "health");

        setTimeout(function () {
            $(".search_wrap select[name='varCode']").val(varCd).attr("selected", true);
            $(".search_wrap select[name='vmlCode']").val(vmlCd).attr("selected", true);
            $(".search_wrap select[name='vehicleName']").val(vehicleNo).attr("selected", true);
            $(".sv_etc_button").attr("disabled", false).removeClass("disabled_button");
        }, 0);
    }
});


// ┌─────────────────────────── click 이벤트 ───────────────────────────┐
window.onload = function () {
    var search = document.getElementById("searchSend"); // 조회 버튼 클릭
    var contentChange = document.getElementById("contentChange"); // 그래프로 보기 버튼 클릭
    var sameTypeVehicleMove = document.getElementById("sameTypeVehicleMove"); // 동종 차량 비교 버튼 클릭

    // ┌─────────────────────────── 조회 ───────────────────────────┐
    search.addEventListener("click", function () {
        varCd = document.getElementById("varCodeList").value;
        vmlCd = document.getElementById("vmlCodeList").value;
        vehicleNo = document.getElementById("vehicleNoList").value;

        let result = selectCheck(varCd, vmlCd, vehicleNo);

        if(result === true) {
            location.href = '/sameVehicleList/' + varCd + "/" + vmlCd + "/" + vehicleNo;
            // $.ajax({
            //     url: "/sameVehicleFirstList",
            //     data: {vmlCd, vehicleNo},
            //     type: "GET",
            //     cacha: false,
            // }).done(function(fragment) {
            //     $("#svFirstList").replaceWith(fragment);
            // });
            //
            // $.ajax({
            //     url: "/sameVehicleMainList",
            //     data: {vmlCd, vehicleNo},
            //     type: "GET",
            //     cacha: false,
            // }).done(function(fragment) {
            //     getSvChart(vmlCd, vehicleNo, "health");
            //
            //     $("#svMainList").replaceWith(fragment);
            //     $("#before_search").hide();
            //     $("#listViewOn").show();
            //     $("#graphViewOn").hide();
            //     $(".sv_etc_button").attr("disabled", false).removeClass("disabled_button");
            // });
        }
    })

    // ┌─────────────────────────── 리스트 & 그래프 전환 ───────────────────────────┐
    contentChange.addEventListener("click", function () {
        let result = selectCheck(varCd, vmlCd, vehicleNo);

        if(result === true) {
            let value = document.getElementById("contentChange").value;
            if(value == "list") { // 그래프로 전환
                if(noneGraphPopup === true) {
                    confirmPopup("조건에 해당하는 그래프가 없습니다.\n다시 조회해주세요.",1,"reopen", "read", "svGraph");
                } else {
                    $("#contentChange").text("리스트로 보기");
                    $("#contentChange").val("graph");
                    $("#listViewOn").hide();
                    $("#graphViewOn").show();
                }
            } else { // 리스트로 전환
                $("#contentChange").text("그래프로 보기");
                $("#contentChange").val("list");
                $("#listViewOn").show();
                $("#graphViewOn").hide();
            }
        }
    })

    // ┌─────────────────────────── 동종 차량 비교 버튼 클릭 ───────────────────────────┐
    sameTypeVehicleMove.addEventListener("click", function () {
        let result = selectCheck(varCd, vmlCd, vehicleNo);

        if(result === true) {
            $.ajax({
                url: "/findCustomerIdAndCarYear",
                data: {vmlCd, vehicleNo},
                type: "GET",
                cacha: false,
                success: function(response) {
                    location.href = "/views/sameTypeVehicle/?vmlCd="+vmlCd+"&carYear="+response.carYear+"&customerId="+response.customerId;
                }
            })
        }
    })
}

// ┌─────────────────────────── 셀렉 박스 체크 ───────────────────────────┐
function selectCheck(varCd, vmlCd, vehicleNo) {
    let result = false;

    if(varCd === "none") {
        confirmPopup("차량 제조사를 선택해주세요.",1,"reopen", "read", "sameVehicle");
    } else if(vmlCd === "none") {
        confirmPopup("차량 모델을 선택해주세요.",1,"reopen", "read", "sameVehicle");
    } else if(vehicleNo === "none") {
        confirmPopup("차량 번호를 선택해주세요.", 1, "reopen", "read", "sameVehicle");
    } else {
        result = true;
    }

    return result;
}

function selectVarCode(object) {
    let varCdNm = $(object).val();
    let vmlCodeSelect = $(object).nextAll("select:first");
    clearSelectOption(object);

    if(varCdNm != "none") {
        $.ajax({
            url: "/getVmlCode/" + varCdNm ,
            data: null,
            type: "GET",
            cache: false,
        }).done(function(fragment) {
            // $("#vmlCode").replaceWith(fragment);
            vmlCodeSelect.replaceWith(fragment);
        });
    }
}

function selectVmlCode(object) {
    let varCdNm = $(object).prevAll("select:first").val();
    let vmlCd = $(object).val();
    let vehicleNoSelect = $(object).nextAll("select:first");
    clearSelectOption(object);

    if( varCdNm != "none" && vmlCd != "none") {
        $.ajax({
            url: "/getVehicleNo/" + varCdNm + "/" + vmlCd ,
            data: null,
            type: "GET",
            cache: false,
        }).done(function(fragment) {
            // $("#vehicleNoList").replaceWith(fragment);
            vehicleNoSelect.replaceWith(fragment);
        });
    }
}

function urlControl(url) {
    let query = url;
    let item = "";
    let count = 0;
    let itemResult = [];
    for(let i = decodeURI(query).length; i >= 0; i--) {
        if(decodeURI(query).slice((i*-1), (i*-1)+1) == '/') {
            itemResult[count] = item;
            item = "";
            count++;
        } else {
            if(i == 0) {
                item += decodeURI(query).slice(-1);
            } else {
                item += decodeURI(query).slice((i*-1), (i*-1)+1);
            }
        }
        if(i==0) {
            itemResult[count] = item;
            item = "";
            count = 0;
        }
    }
    return itemResult;
}