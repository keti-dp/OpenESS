
$(document).ready(function () {
});


function getVarCodeNm(vmlCd, vehicleNo) {
    $.ajax({
        url: "/getVarCodeNm/" + vmlCd,
        data: null,
        type: "GET",
        cacha: false,
        success: function(response) {
            let varCdNm = response;
            location.href = "/sameVehicleList/" + varCdNm + "/" + vmlCd + "/" + vehicleNo;
        },
        error: function (error) {
            console.log("getVarCodeNm error\n", error);
        }
    })
}