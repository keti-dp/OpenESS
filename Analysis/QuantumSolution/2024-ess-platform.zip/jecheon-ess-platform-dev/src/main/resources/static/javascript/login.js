$(document).ready(function(){
    $("#loginForm").on('keypress', function(e){
        if(e.keyCode == '13') {
            loginUser();
        }
    });
});

function loginUser(){
    var username = $("#loginForm input[name='username']").val();
    var password = $("#loginForm input[name='password']").val();
    let msg = "";

    if(username != '' && password != '') {

        $.ajax({
            url: "/signIn",
            data: {"username" : username, "password": password},
            type: "POST",
            cache: false
        }).done(function(response) {
            // alert(response.statusCode+"\n"+response.data.message+"\n"+response.data.logInUsername)
            if (response.data.message == "error") {
                msg = "아이디 또는 비밀번호를 확인해주세요.";
                $("#loginErrorText").html(msg);
                $("#loginErrorTextSwitch").show();
            } else {
                $("#loginErrorTextSwitch").hide();
                location.href ="/views/main";
            }
        })
    } else {
        msg = "아이디와 비밀번호를 정확히 입력해주세요.";
        $("#loginErrorText").html(msg);
        $("#loginErrorTextSwitch").show();
        // confirmPopup(msg, 1, "close");
    }
}