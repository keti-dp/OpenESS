import { createRouter, createWebHistory } from 'vue-router'
import LoginView from '@/views/LoginView.vue'
import store from '@/store'
import MainView from '@/views/MainView.vue'
import {ElMessageBox} from "element-plus";
import DetailView from "@/views/DetailView";

const routes = [
  {
    path: '/',
    name: 'login',
    component: LoginView
  },
  {
    path: '/mainView',
    name: 'mainView',
    component: MainView,
    meta: { auth: true }
  },
  {
    path: '/detailView',
    name: 'detailView',
    component: DetailView,
    meta: { auth: true }
  },
  // {
  //   path: '/detailView/:evccid?',
  //   name: 'detailView',
  //   component: DetailView,
  //   meta: { auth: true }
  // },
]

const router = createRouter({
  mode: history,
  history: createWebHistory(process.env.BASE_URL),
  routes
})

router.beforeEach(async (to, from, next) => {
  const userId = store.state.loginInfo.userId
  console.log('user info = ' + userId)
  if (to.matched.some(r => r.meta.auth) && userId === '') {
    await ElMessageBox.alert('This page requires login')
    next({name: 'login' })
  } else {
    next()
  }
})

export default router
