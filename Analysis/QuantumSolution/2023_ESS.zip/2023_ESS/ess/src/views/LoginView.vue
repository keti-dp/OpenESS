<template>
  <div>
    <el-container>
      <el-main>
        <div class="display_form">
          <div class="display_form_cell">
            <div class="img-wrap">
              <!--<img src="/images/top-logo-02.png" alt="logo-01">-->
              <!--<img src="/images/q-sol-white.png" alt="logo-02" class="top-logo" style="width: 180px">-->
            </div>
            <el-col class="login-form">
              <h2 class="login-title">
                충전 데이터 기반의 <br><span>전기차 특화 진단 서비스</span>
              </h2>
              <el-form ref="form" v-model="this.loginInfo" label-width="120px">
                <div class="input-wrap">
                  <label class="login-id" for="">사용자 아이디</label>
                  <el-input class="login-input" placeholder="아이디를 입력하세요" id="id" ref="id" autofocus
                            v-model="this.loginInfo.userId"> <!-- @keyup.enter.native="handleEnter"-->
                  </el-input>f
                </div>
                <div class="input-wrap">
                  <label class="login-id" for="">비밀번호</label>
                  <el-input class="login-input" placeholder="비밀번호를 입력하세요." id="password"
                            ref="password" v-model="this.loginInfo.password" show-password> <!-- @keyup.enter.native="handleEnter"-->
                  </el-input>
                </div>
                <div class="input-wrap">
                  <el-button type="primary" @click="login" class="login-button">로그인</el-button>
                </div>
              </el-form>

            </el-col>
          </div>
          <el-footer>
            <p class="copyright">© 2023 Quantum Solution. ALL RIGHTS RESERVED.</p>
          </el-footer>
        </div>
      </el-main>
    </el-container>


<!--    <div class="modal fade" id="login-error" role="dialog" aria-hidden="false">-->
<!--      <div class="modal-dialog modal-content" role="document" >-->
<!--        <div class="modal-common">-->
<!--          <div class="modal-header">-->
<!--            <h3 id="modalTitle"></h3>-->
<!--          </div>-->
<!--          <div class="modal-body">-->
<!--            <img src="/images/error-icon.png" alt="">-->
<!--            &lt;!&ndash;<template v-if="etc.isError">-->
<!--                              <img src="/images/error-icon.png" alt="">-->
<!--                          </template>-->
<!--                          <template v-else>-->
<!--                              <img src="/images/uploaded.png" alt="">-->
<!--                          </template>&ndash;&gt;-->
<!--            <p id="modalMsg"></p>-->
<!--          </div>-->
<!--          <div class="modal-footer">-->
<!--            <button onclick="closePopup()" type="button" data-dismiss="modal" aria-label="Close" class="exit">닫기</button>-->
<!--          </div>-->
<!--        </div>-->
<!--      </div>-->
<!--    </div>-->
  </div>
</template>



<script>
import axios from "axios";
import router from "@/router";
import store from "@/store/index";

export default {
  name: "LoginView",
  data() {
    return {
      loginInfo: store.state.loginInfo
    }
  },

  computed: {
    cLoginInfo() {
      return store.state.loginInfo;
    }
  },

  methods: {
    login() {
      console.log("로그인 시도")
      axios
          .post("/api/security/login", this.loginInfo)
          .then((response) => {
            if(response.data === 1) {
              router.push({name: 'mainView'})
            } else {
              alert("입력하신 로그인 정보가 알맞지 않습니다.")
            }
          })
    }

  },

  mounted() {
  }
}
</script>

<style>
@import "../assets/static/css/login.css";
</style>
<style scoped>
</style>