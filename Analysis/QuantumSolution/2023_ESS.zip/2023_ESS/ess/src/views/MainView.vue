<template>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no">
    <title>충전 데이터 기반의 전기차 특화 진단 서비스</title>
  </head>

  <div>
    <el-container>
      <el-header class="header" style="padding: 0px">
        <div class="header-top">
          <div class="popup-wrap">
            과제명 : 재제조 배터리용 고정밀 분석 장비 구축
            <p>충전 데이터 기반의 전기차 특화 진단 서비스</p>
          </div>
        </div>

        <div class="header-bottom">
          <div class="img-wrap">
          </div>
          <el-menu class="header-menu main-menu" style="background-color: #f8981f"> <!-- mode="horizontal" unique-opened-->
            <el-menu-item index="5" class="language" style="display: inline-block">
              <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <img src="../assets/images/kor.png" alt="" style="margin: 0px; vertical-align: middle">
                  <span>KOR</span>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                  <a class="dropdown-item" href="#">KOR</a>
                  <a class="dropdown-item" href="#">ENG</a>
                </div>
              </div>
            </el-menu-item>
            <el-menu-item index="4" @click="logout()" style="display: inline-block">
              <div style="background-color: #f8981f">
                <img src="../assets/images/logout.png" alt="">
                <p>로그아웃</p>
              </div>
            </el-menu-item>
          </el-menu>
        </div>
      </el-header>
    </el-container>

    <el-container>
      <div>
        <el-row>
          <el-col :span="24">
            <el-menu class="left-menu" :default-active="activeLeftMenuIndex" style="background-color: #3e454f">
              <el-menu-item index="1">
                <el-link @click="leftMenuNumberOne" style="color: #f8981f">
                  <img src="../assets/images/kor.png" class="menu-icon default" alt="menu-icon-01">
                  <img src="../assets/images/menu-icon-01.png" class="menu-icon active" alt="menu-icon-01">
                  <span>배터리 진단</span>
                </el-link>
              </el-menu-item>
            </el-menu>
          </el-col>
        </el-row>
      </div>
  <!-- ↑ head, header, side 기본 설정  -->

      <div class="container-wrap">
        <div class="main-container">
          <div class="main-inner" style="margin: 0vw 0vw 0vw 8vw">
            <div class="title" style="margin: 50px 0px -100px 0px">
              <img src="../assets/images/title-icon-01.png" alt="">
              <h3>배터리 진단</h3>
            </div>
            <el-row class="contents-wrap">
              <el-col class="contents-fir">
                <el-table
                    :data="mainListData"
                    stripe
                    style="width: 100%">
                  <el-table-column
                      prop="testId"
                      label="Test Id"
                      width="180" style="text-align: center">
                  </el-table-column>
                  <el-table-column
                      prop="startDt"
                      label="Start Date"
                      width="180" style="text-align: center">
                  </el-table-column>
                  <el-table-column
                      prop="endDt"
                      label="End Date"
                      width="180" style="text-align: center">
                  </el-table-column>
                  <el-table-column
                      prop="startSoc"
                      label="Start Soc"
                      width="180" style="text-align: center">
                  </el-table-column>
                  <el-table-column
                      prop="lastSoc"
                      label="Last Soc"
                      width="180" style="text-align: center">
                  </el-table-column>
                  <el-table-column
                      prop="soh"
                      label="soh"
                      width="180" style="text-align: center">
                  </el-table-column>
                  <el-table-column
                      prop="registDt"
                      label="Regist Date"
                      width="180" style="text-align: center">
                  </el-table-column>
                  <el-table-column
                      label="Charge Count"
                      width="180" style="text-align: center">

                    <template v-slot="scope">
                      <el-link @click="goDetailView(scope.row.evccid)">{{scope.row.chargeCount}}</el-link>
                    </template>

                  </el-table-column>
                </el-table>
                <el-pagination layout="prev, pager, next" :total="mainListDataCount"
                               style="display: inline-flex"
                               :page-size="mainListDataSearchData.countPerPage" v-model:current-page.sync="mainListDataSearchData.pageNo"
                               @current-change="getMainListData">
                </el-pagination>

<!--                <el-col style="text-align: center; margin-top: 10px">-->
<!--                  <el-button type="info" @click="">시작</el-button>-->
<!--                  <el-button type="danger" @click="">종료</el-button>-->
<!--                </el-col>-->
              </el-col>
            </el-row>
          </div>
        </div>
        <el-footer th:replace="layout/footer.html :: fragment-footer"></el-footer>
      </div>

    </el-container>
  </div>
</template>

<script>
import router from "@/router";
import axios from "axios";
import store from "@/store/index";

export default {
  name: "MainView",

  data() {
    return {
      activeLeftMenuIndex: "1",
      activateIndex : 0,
      mainListData: store.state.mainListData,
      mainListDataCount: store.state.mainListDataCount,
      mainListDataSearchData: store.state.mainListDataSearchData
    }
  },

  methods: {
    logout() {
      console.log("--- methods logout Run ---")
      axios
          .post("/api/security/logout", null)
          .then(() => {
            router.push({name: 'login'})
          })
          .catch((error) => {
            console.log(error);
            alert ("로그아웃하는 중 에러가 발생했습니다.");
          })
    },
    getMainListData() {
      console.log("--- methods getMainListData Run ---")
      axios
          .get("/api/ess", {params:this.mainListDataSearchData})
          .then((response) => {
            this.mainListData = response.data.list;
            this.mainListDataCount = response.data.count;
            // this.$store.dispatch('mainListSave', {list: response.data.list, count: response.data.count});
          })
    },
    goDetailView(evccid) {
      this.$store.commit('evccidSave', evccid)
      router.push({name: 'detailView'});
      // router.push({name: 'detailView', params: {evccid: evccid}});
    },

    leftMenuNumberOne() {
      console.log("--- methods leftMenuNumberOne Run ---")
      router.push({name:'mainView'})
    }
  },

  mounted() {
    this.$store.commit('pageNoClear')
    this.getMainListData();
  }
}
</script>

<style>
@import "../assets/static/css/startwithuploadtimesoc.css";
@import "../assets/static/css/common.css";
@import "../assets/static/css/themify-icons.css";
@import "../assets/static/css/all.min.css";
</style>
<style scoped>

</style>