import {createStore} from 'vuex'
// import axios from 'axios'
import createPersistedState from 'vuex-persistedstate'
// import router from '@/router'
// import {ElMessageBox} from "element-plus";
// import Vuex from 'vuex';
// export default store
// const store = new Vuex.Store({

export default createStore({
  state: {
    loginInfo: {
      userId: '',
      password: ''
    },
    mainListData: [],
    mainListDataCount: 0,
    mainListDataSearchData: {
      pageNo: 1,
      countPerPage: 10
    },
    // intervalApply: false,
    // user: {
    //   managerId: '',
    //   managerNm: ''
    // },
    // testState: {
    //   name: '정규',
    //   age: 32,
    //   sync: 'defaultSync',
    //   count: 1,
    // },
  },
  getters: {},
  mutations: {
    setUser(state, _user) {
      state.user = _user
    },
    mainListSaveMutations(state, payload) {
      console.log("--- Store Mutations mainListSaveMutations Run ---");
      state.mainListData = payload.list;
      state.mainListDataCount = payload.count;
    },
    evccidSave(state, payload) {
      console.log("--- Store Mutations evccidSave Run " + payload + " ---")
      state.evccid = payload;
    },
    pageNoClear(state) {
      console.log("--- Store Mutations pageNoClear Run ---")
      state.mainListDataSearchData.pageNo = 1;
    }
  },
  actions: {
    mainListSave({commit}, payload) {
      console.log("--- Store Actions mainListSave Run ---");
      commit('mainListSaveMutations', payload);
    }
  },
  modules: {
  },
  plugins: [
    createPersistedState({
      storage: window.sessionStorage
    })
  ]
})
